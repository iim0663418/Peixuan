<template>
  <div class="purple-star-chart-container">
    <!-- 載入狀態 -->
    <div v-if="isLoading" class="loading-state">
      <div class="loading-spinner"></div>
      <p>{{ $t('purpleStarChart.loading') }}</p>
    </div>

    <!-- 錯誤狀態 -->
    <div v-else-if="error" class="error-state">
      <div class="error-icon">⚠️</div>
      <h3>{{ $t('purpleStarChart.loadError') }}</h3>
      <p>{{ error }}</p>
      <button @click="$emit('retry')" class="retry-button">
        {{ $t('purpleStarChart.retry') }}
      </button>
    </div>

    <!-- 命盤內容 -->
    <div v-else-if="chartData" class="chart-content">
      <!-- 調試資訊 -->
      <div v-if="false" class="debug-info" style="background: #f0f0f0; padding: 10px; margin-bottom: 10px; font-size: 12px;">
        <p><strong>調試資訊:</strong></p>
        <p>宮位數量: {{ chartData?.palaces?.length || 0 }}</p>
        <p>大限數量: {{ chartData?.daXian?.length || 0 }}</p>
        <p>小限數量: {{ chartData?.xiaoXian?.length || 0 }}</p>
        <p>流年太歲數量: {{ chartData?.liuNianTaiSui?.length || 0 }}</p>
        <p>五行局: {{ chartData?.fiveElementsBureau || '未知' }}</p>
      </div>

      <!-- 命盤資訊標題 -->
      <div class="chart-header">
        <h2>{{ $t('purpleStarChart.title') }}</h2>
        <div class="header-actions">
          <button @click="showGuideModal = true" class="guide-button">
            <span class="guide-icon">💡</span>
            進階功能說明
          </button>
        </div>
      </div>
      
      <!-- 簡要解讀區域 -->
      <div v-if="showSummary && chartSummary" class="chart-summary">
        <div class="summary-header">
          <h3>{{ $t('purpleStarChart.chartSummary') }}</h3>
          <button @click="showSummary = !showSummary" class="toggle-summary-button">
            {{ $t('purpleStarChart.hideSummary') }}
          </button>
        </div>
        <div class="summary-content">
          <div class="summary-features">
            <div v-for="(feature, idx) in chartSummary.features" :key="`feature-${idx}`" class="feature-item">
              <span class="feature-icon">✧</span>
              <span class="feature-text">{{ feature }}</span>
            </div>
          </div>
          <div class="summary-detailed">
            <p>{{ chartSummary.detailedSummary }}</p>
          </div>
          <div class="interaction-hint" v-if="showInteractionTips">
          <div class="hint-content">
            <span class="hint-icon">💡</span>
            <div class="hint-text-container">
              <span class="hint-text">{{ $t('purpleStarChart.interactionTips.comprehensive') }}</span>
              <span class="swipe-hint">{{ $t('purpleStarChart.interactionTipDesc') }} <span class="swipe-arrow">↔️</span></span>
            </div>
            <button @click="showInteractionTips = false" class="close-hint">×</button>
          </div>
          </div>
        </div>
      </div>
      
      <!-- 當解讀區域被隱藏時顯示的重新展開按鈕 -->
      <div v-else-if="chartSummary" class="show-summary-button-container">
        <button @click="showSummary = true" class="show-summary-button">
          {{ $t('purpleStarChart.showSummary') }}
        </button>
      </div>


      <!-- 主命盤網格 -->
      <div class="chart-grid" :class="viewMode">
        <div 
          v-for="(position, index) in gridLayout" 
          :key="`position-${index}`"
          :class="['palace-cell', getPositionClass(position, index)]"
          :data-palace-zhi="position !== 'center' ? position : undefined"
          :data-palace-index="position !== 'center' ? getPalaceByZhi(position)?.index : undefined"
          @click="handlePalaceClick(position)"
        >
          <!-- 中央太極 -->
          <div v-if="position === 'center'" class="palace-center">
            <h4>{{ $t('purpleStarChart.centerPalace') }}</h4>
            <div class="center-info">
              <p v-if="chartData.fiveElementsBureau">{{ chartData.fiveElementsBureau }}</p>
              <p>{{ $t('purpleStarChart.mingPalace') }}: {{ getMingPalaceName() }}</p>
              <p>{{ $t('purpleStarChart.shenPalace') }}: {{ getShenPalaceName() }}</p>
            </div>
          </div>

          <!-- 宮位內容 -->
          <div v-else-if="getPalaceByZhi(position)" 
               class="palace-content" 
               :class="getPalaceFortuneClass(getPalaceByZhi(position))"
               :data-palace-zhi="position">
            <div class="palace-header">
              <span class="palace-name">{{ getPalaceByZhi(position)?.name }}</span>
              <span class="palace-zhi">{{ position }}</span>
              <span v-if="isMingPalace(position)" class="ming-indicator">命</span>
              <span v-if="isShenPalace(position)" class="shen-indicator">身</span>
              <span v-if="getPalaceByZhi(position)?.fortuneType" 
                    :class="['fortune-indicator', `fortune-${getPalaceByZhi(position)?.fortuneType}`]">
                {{ getPalaceByZhi(position)?.fortuneType }}
              </span>
            </div>

            <div class="stars-container">
              <!-- 檢查是否為空宮 -->
              <EmptyPalaceIndicator 
                v-if="isEmptyPalace(position)"
                :borrowed-palace="getBorrowedPalaceInfo(position)"
                class="empty-palace-indicator"
              />
              
              <!-- 顯示星曜 -->
              <div 
                v-for="star in getPalaceByZhi(position)?.stars" 
                :key="star.name"
                :class="getStarClasses(star)"
                @click.stop="handleStarClick(star)"
                :title="getStarTooltip(star)"
              >
                <span class="star-name">{{ star.name }}</span>
                
                <!-- 星曜亮度指示器 -->
                <StarBrightnessIndicator 
                  v-if="star.brightness" 
                  :brightness="star.brightness" 
                />
                
                <!-- 四化顯示 -->
                <span v-if="star.transformations && star.transformations.length > 0" 
                      :class="['transformations', { 'detailed-transformations': viewMode === 'detailed' }]">
                  <span v-for="trans in star.transformations" 
                        :key="trans" 
                        :class="`transformation-${trans}`">{{ trans }}</span>
                </span>
                
                <!-- 星曜屬性 -->
                <span v-if="star.attribute" 
                      :class="['star-attribute', `attribute-${star.attribute}`]">
                  {{ star.attribute }}
                </span>
                
                <!-- 星曜類型標記 -->
                <span v-if="star.type === 'minor'" class="star-type-badge minor">
                  雜
                </span>
              </div>
            </div>

            <!-- 特徵解析提示 (詳細模式) -->
            <div v-if="viewMode === 'detailed'" class="feature-hints">
              <FeatureHintsDisplay 
                :palace="getPalaceByZhi(position)"
                :position="position"
                :is-empty="isEmptyPalace(position)"
                :borrowed-info="getBorrowedPalaceInfo(position)"
              />
            </div>

            <!-- 大限小限資訊 (詳細模式) -->
            <div v-if="viewMode === 'detailed'" class="cycles-info">
              <div v-if="getDaXianInfo(position)" class="da-xian-info">
                <small>{{ formatDaXianInfo(getDaXianInfo(position)!) }}</small>
              </div>
              <div v-if="getXiaoXianInfo(position)" class="xiao-xian-info">
                <small>{{ formatXiaoXianInfo(getXiaoXianInfo(position)!) }}</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 命盤解讀區域 -->

      <!-- 大限小限詳細資訊 (可選顯示) -->
      <div v-if="showCyclesDetail && chartData.daXian" class="cycles-detail">
        <div class="cycles-detail-header">
          <h3>{{ $t('purpleStarChart.majorCycles') }}</h3>
          <div class="cycles-explanation">
            <div class="info-icon">ℹ️</div>
            <div class="info-text">
              大限是紫微斗數命盤中表示人生階段的重要概念，每個大限代表約10年的時間。大限與本命盤星曜互動，
              揭示該階段的主要能量流動和關鍵課題。每個大限的宮位和星曜組合，預示著該時期的主要生活主題和機遇挑戰。
            </div>
          </div>
        </div>
        <div class="cycles-grid">
          <div 
            v-for="cycle in chartData.daXian" 
            :key="`daxian-${cycle.startAge}`"
            class="cycle-item"
            :class="{ current: isCurrentCycle(cycle) }"
          >
            <div class="cycle-header">
              <span class="cycle-age">{{ cycle.startAge }}-{{ cycle.endAge }}{{ $t('purpleStarChart.years') }}</span>
              <span class="cycle-palace">{{ cycle.palaceName }}</span>
            </div>
            <div class="cycle-zhi">{{ cycle.palaceZhi }}</div>
            <div class="cycle-description">
              大限落在{{ cycle.palaceName }}，著重於{{ getCycleTheme(cycle.palaceName) }}主題。
            </div>
          </div>
        </div>
      </div>

      <!-- 星曜詳細資訊彈窗 -->
      <div v-if="selectedStar" class="star-detail-modal" @click="closeStarDetail">
        <div class="modal-content" @click.stop>
          <div class="modal-header">
            <h3>{{ selectedStar.name }}</h3>
            <button @click="closeStarDetail" class="close-button">×</button>
          </div>
          <div class="modal-body">
            <p><strong>{{ $t('purpleStarChart.starType') }}:</strong> {{ $t(`purpleStarChart.starTypes.${selectedStar.type}`) }}</p>
            <p><strong>{{ $t('purpleStarChart.palace') }}:</strong> {{ getStarPalaceName(selectedStar) }}</p>
            
            <!-- 星曜屬性資訊 -->
            <div class="star-attributes-section">
              <div v-if="selectedStar.attribute" class="attribute-item">
                <strong>吉凶屬性：</strong>
                <span :class="`attribute-tag attribute-${selectedStar.attribute}`">{{ selectedStar.attribute }}</span>
              </div>
              <div v-if="selectedStar.propertyType" class="attribute-item">
                <strong>陰陽屬性：</strong>
                <span class="attribute-tag">{{ selectedStar.propertyType }}</span>
              </div>
              <div v-if="selectedStar.element" class="attribute-item">
                <strong>五行屬性：</strong>
                <span class="attribute-tag">{{ selectedStar.element }}</span>
              </div>
              <div v-if="selectedStar.strength !== undefined" class="attribute-item">
                <strong>星曜強度：</strong>
                <span class="attribute-tag">{{ selectedStar.strength }}/10</span>
              </div>
            </div>
            
            <!-- 星曜描述 -->
            <div v-if="selectedStar.description" class="star-description">
              <strong>星曜特點：</strong>
              <p>{{ selectedStar.description }}</p>
            </div>
            
            <!-- 四化資訊 -->
            <div v-if="selectedStar.transformations && selectedStar.transformations.length > 0">
              <strong>{{ $t('purpleStarChart.transformations') }}:</strong>
              <ul>
                <li v-for="trans in selectedStar.transformations" :key="trans">
                  {{ $t(`purpleStarChart.transformationTypes.${trans}`) }}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- 功能指南彈窗 -->
      <PurpleStarGuideModal 
        :visible="showGuideModal"
        @close="showGuideModal = false"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import StarBrightnessIndicator from './StarBrightnessIndicator.vue';
import EmptyPalaceIndicator from './EmptyPalaceIndicator.vue';
import PurpleStarGuideModal from './PurpleStarGuideModal.vue';
import FeatureHintsDisplay from '@/components/FeatureHintsDisplay.vue';
import type { 
  PurpleStarChart, 
  Palace, 
  Star, 
  DaXianInfo, 
  XiaoXianInfo
} from '@/types/astrologyTypes';

// 計算資訊介面定義
interface CalculationInfo {
  birthInfo: {
    solarDate: string;
    gender: string;
  };
}

const { t } = useI18n();

// Props
interface Props {
  chartData?: PurpleStarChart | null;
  calculationInfo?: CalculationInfo | null;
  isLoading?: boolean;
  error?: string | null;
  showCyclesDetail?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  chartData: null,
  calculationInfo: null,
  isLoading: false,
  error: null,
  showCyclesDetail: false
});

// Emits
const emit = defineEmits<{
  retry: [];
  palaceClick: [palace: Palace];
  starClick: [star: Star];
  export: [format: string];
}>();

// 響應式資料
const viewMode = ref<'simple' | 'detailed'>('detailed');
const displayMode = ref<'compact' | 'expanded'>('expanded'); // 保留舊的控制變數，保持向後兼容
const selectedStar = ref<Star | null>(null);
const selectedPalace = ref<Palace | null>(null); // 選中的宮位
const showInteractionTips = ref<boolean>(true); // 顯示互動提示
const showSummary = ref<boolean>(true); // 顯示簡要解讀
const showGuideModal = ref<boolean>(false); // 顯示功能指南彈窗
const activeDomain = ref<'career' | 'wealth' | 'marriage' | 'health' | 'education' | 'social'>('career');
const activePalaceName = ref<string>('');
const interpretationMode = ref<'fortune' | 'basic' | 'advanced'>('fortune');

// 四化流動和多層次能量數據
const transformationFlows = computed(() => {
  // 從 TransformationStarsDisplay 的邏輯中提取能量流動數據
  const flows: Record<number, {
    palaceIndex: number
    palaceName: string
    energyScore: number
    majorInfluences: string[]
  }> = {};

  if (props.chartData?.palaces) {
    props.chartData.palaces.forEach(palace => {
      let energyScore = 0;
      const influences: string[] = [];

      // 計算宮位能量分數
      palace.stars.forEach(star => {
        if (star.transformations) {
          star.transformations.forEach(trans => {
            switch (trans) {
              case '祿':
                energyScore += 3;
                influences.push(`${star.name}化祿`);
                break;
              case '權':
                energyScore += 2;
                influences.push(`${star.name}化權`);
                break;
              case '科':
                energyScore += 1;
                influences.push(`${star.name}化科`);
                break;
              case '忌':
                energyScore -= 3;
                influences.push(`${star.name}化忌`);
                break;
            }
          });
        }

        // 根據星曜屬性調整分數
        if (star.attribute === '吉') {
          energyScore += 1;
        } else if (star.attribute === '凶') {
          energyScore -= 1;
        }
      });

      flows[palace.index] = {
        palaceIndex: palace.index,
        palaceName: palace.name,
        energyScore,
        majorInfluences: influences
      };
    });
  }

  return flows;
});

const multiLayerEnergies = computed(() => {
  // 模擬多層次能量數據
  const energies: Record<number, {
    palaceIndex: number
    palaceName: string
    baseEnergy: number
    daXianEnergy: number
    liuNianEnergy: number
    totalEnergy: number
    interpretation: string
  }> = {};

  if (props.chartData?.palaces) {
    props.chartData.palaces.forEach(palace => {
      const baseEnergy = transformationFlows.value[palace.index]?.energyScore || 0;
      const daXianEnergy = Math.floor(Math.random() * 6) - 3; // 模擬大限能量 -3 to +3
      const liuNianEnergy = Math.floor(Math.random() * 4) - 2; // 模擬流年能量 -2 to +2
      const totalEnergy = baseEnergy + daXianEnergy + liuNianEnergy;

      let interpretation = '';
      if (totalEnergy > 5) {
        interpretation = '能量極佳，是發展的黃金時期';
      } else if (totalEnergy > 2) {
        interpretation = '能量良好，適合積極行動';
      } else if (totalEnergy > -2) {
        interpretation = '能量平穩，宜穩健發展';
      } else if (totalEnergy > -5) {
        interpretation = '能量偏弱，需謹慎行事';
      } else {
        interpretation = '能量低迷，宜保守觀望';
      }

      energies[palace.index] = {
        palaceIndex: palace.index,
        palaceName: palace.name,
        baseEnergy,
        daXianEnergy,
        liuNianEnergy,
        totalEnergy,
        interpretation
      };
    });
  }

  return energies;
});


// 計算屬性
// 命盤概要解讀
const chartSummary = computed(() => {
  if (!props.chartData || !props.chartData.palaces || !Array.isArray(props.chartData.palaces)) return null;
  
  // 從命盤資料中提取重要資訊生成簡要解讀
  const mainStars = props.chartData.palaces.flatMap(p => 
    p.stars && Array.isArray(p.stars) 
      ? p.stars.filter(s => s.type === 'main' || (s.transformations && s.transformations.length)) 
      : []
  );
  
  const mainStarCounts = {
    '吉': mainStars.filter(s => s.attribute === '吉').length,
    '凶': mainStars.filter(s => s.attribute === '凶').length,
    '中性': mainStars.filter(s => s.attribute === '中性').length
  };
  
  const hasMingPalaceGoodStars = props.chartData.palaces[props.chartData.mingPalaceIndex]?.stars
    .some(s => s.type === 'main' && s.attribute === '吉');
  
  const transformationCount = mainStars.filter(s => s.transformations?.length).length;
  
  // 命盤特徵摘要
  const features = [];
  
  if (mainStarCounts['吉'] > mainStarCounts['凶']) {
    features.push('吉星較多，整體運勢偏向正面');
  } else if (mainStarCounts['凶'] > mainStarCounts['吉']) {
    features.push('凶星較多，人生挑戰較大');
  } else {
    features.push('吉凶星均衡，順逆交替');
  }
  
  if (hasMingPalaceGoodStars) {
    features.push('命宮有吉星入駐，基礎運勢良好');
  }
  
  if (transformationCount > 3) {
    features.push('四化星豐富，命盤變化較大');
  }
  
  // 從命宮情況添加特徵
  const mingPalace = props.chartData.palaces[props.chartData.mingPalaceIndex];
  if (mingPalace) {
    const mingStars = mingPalace.stars.filter(s => s.type === 'main');
    if (mingStars.length > 2) {
      features.push('命宮聚集多顆主星，命運變化豐富');
    }
    
    // 檢查命宮是否有特定星曜
    const hasPurpleStar = mingStars.some(s => s.name.includes('紫微'));
    if (hasPurpleStar) {
      features.push('紫微星入命，具有領導才能與權威性');
    }
  }
  
  // 自動生成命盤摘要
  let generatedSummary = '';
  if (props.chartData.comprehensiveInterpretation?.overallLifePattern) {
    generatedSummary = props.chartData.comprehensiveInterpretation.overallLifePattern;
  } else {
    // 當後端未提供解讀時自動生成
    const mingPalaceName = mingPalace?.name || '命宮';
    const fortuneType = mainStarCounts['吉'] > mainStarCounts['凶'] ? '較為順遂' : 
                        mainStarCounts['凶'] > mainStarCounts['吉'] ? '較多挑戰' : '順逆參半';
    
    generatedSummary = `此命盤以${mingPalaceName}為中心，整體運勢${fortuneType}。` + 
                       `命盤中共有${mainStars.length}顆主要星曜，其中吉星${mainStarCounts['吉']}顆，` +
                       `凶星${mainStarCounts['凶']}顆。在紫微斗數的十二宮位結構中，` + 
                       `每個宮位代表人生不同領域，宮位中的星曜組合則揭示了各領域的特質與發展。` +
                       `透過分析命宮、財帛宮、官祿宮等關鍵宮位的星曜組合，可進一步了解命主的潛能與挑戰。`;
  }
  
  return {
    features,
    detailedSummary: generatedSummary
  };
});

const activeDomainAnalysis = computed(() => {
  if (!props.chartData?.domainAnalyses) return null;
  return props.chartData.domainAnalyses.find(d => d.domain === activeDomain.value) || null;
});

const activePalaceInterpretation = computed(() => {
  if (!props.chartData?.palaceInterpretations || !activePalaceName.value) return null;
  return props.chartData.palaceInterpretations.find(p => p.palaceName === activePalaceName.value) || null;
});

// 十二地支命盤網格佈局 (傳統佈局：逆時針)
const gridLayout = [
  '巳', '午', '未', '申',
  '辰', 'center', 'center', '酉', 
  '卯', 'center', 'center', '戌',
  '寅', '丑', '子', '亥'
];

// 地支到索引的映射
const zhiToIndex: Record<string, number> = {
  '子': 0, '丑': 1, '寅': 2, '卯': 3, '辰': 4, '巳': 5,
  '午': 6, '未': 7, '申': 8, '酉': 9, '戌': 10, '亥': 11
};

// 方法
const getPalaceByZhi = (zhiName: string): Palace | undefined => {
  if (!props.chartData || !props.chartData.palaces || zhiName === 'center') return undefined;
  return props.chartData.palaces.find(palace => palace.zhi === zhiName);
};

const getPositionClass = (position: string, index: number): string => {
  const classes = [`grid-position-${index}`];
  
  if (position === 'center') {
    classes.push('center-position');
  } else {
    classes.push(`zhi-${position}`);
    
    if (isMingPalace(position)) classes.push('ming-palace');
    if (isShenPalace(position)) classes.push('shen-palace');
  }
  
  return classes.join(' ');
};

const getStarClasses = (star: Star): string[] => {
  const classes = ['star-item', `star-${star.type}`];
  
  if (star.transformations) {
    star.transformations.forEach(trans => {
      classes.push(`transform-${trans}`);
    });
  }
  
  return classes;
};

const getStarTooltip = (star: Star): string => {
  let tooltip = `${star.name} (${t(`purpleStarChart.starTypes.${star.type}`)})`;
  
  // 添加亮度資訊
  if (star.brightness) {
    tooltip += ` - 亮度: ${star.brightness}`;
  }
  
  // 添加星曜屬性
  if (star.attribute) {
    tooltip += ` - 屬性: ${star.attribute}`;
  }
  
  // 添加四化資訊
  if (star.transformations && star.transformations.length > 0) {
    tooltip += ` - 四化: ${star.transformations.map(t => t).join(', ')}`;
  }
  
  // 添加描述
  if (star.description) {
    tooltip += `\n${star.description}`;
  }
  
  return tooltip;
};

const isMingPalace = (zhiName: string): boolean => {
  if (!props.chartData || !props.chartData.palaces || !Array.isArray(props.chartData.palaces)) return false;
  
  // 確保 mingPalaceIndex 存在且有效
  if (typeof props.chartData.mingPalaceIndex !== 'number' || 
      props.chartData.mingPalaceIndex < 0 || 
      props.chartData.mingPalaceIndex >= props.chartData.palaces.length) {
    return false;
  }
  
  const mingPalace = props.chartData.palaces[props.chartData.mingPalaceIndex];
  return mingPalace && mingPalace.zhi === zhiName;
};

const isShenPalace = (zhiName: string): boolean => {
  if (!props.chartData || !props.chartData.palaces || !Array.isArray(props.chartData.palaces)) return false;
  
  // 確保 shenPalaceIndex 存在且有效
  if (typeof props.chartData.shenPalaceIndex !== 'number' || 
      props.chartData.shenPalaceIndex < 0 || 
      props.chartData.shenPalaceIndex >= props.chartData.palaces.length) {
    return false;
  }
  
  const shenPalace = props.chartData.palaces[props.chartData.shenPalaceIndex];
  return shenPalace && shenPalace.zhi === zhiName;
};

const getMingPalaceName = (): string => {
  if (!props.chartData || !props.chartData.palaces || !Array.isArray(props.chartData.palaces)) return '';
  
  // 確保 mingPalaceIndex 存在且有效
  if (typeof props.chartData.mingPalaceIndex !== 'number' || 
      props.chartData.mingPalaceIndex < 0 || 
      props.chartData.mingPalaceIndex >= props.chartData.palaces.length) {
    return '';
  }
  
  const mingPalace = props.chartData.palaces[props.chartData.mingPalaceIndex];
  return mingPalace?.name || '';
};

const getShenPalaceName = (): string => {
  if (!props.chartData || !props.chartData.palaces || !Array.isArray(props.chartData.palaces)) return '';
  
  // 確保 shenPalaceIndex 存在且有效
  if (typeof props.chartData.shenPalaceIndex !== 'number' || 
      props.chartData.shenPalaceIndex < 0 || 
      props.chartData.shenPalaceIndex >= props.chartData.palaces.length) {
    return '';
  }
  
  const shenPalace = props.chartData.palaces[props.chartData.shenPalaceIndex];
  return shenPalace?.name || '';
};

const getDaXianInfo = (zhiName: string): DaXianInfo | undefined => {
  if (!props.chartData?.daXian) return undefined;
  return props.chartData.daXian.find(cycle => cycle.palaceZhi === zhiName);
};

const getXiaoXianInfo = (zhiName: string): XiaoXianInfo | undefined => {
  if (!props.chartData?.xiaoXian) return undefined;
  // 這裡可能需要根據當前年齡或指定年齡來查找小限
  return props.chartData.xiaoXian.find(cycle => cycle.palaceZhi === zhiName);
};

const formatDaXianInfo = (cycle: DaXianInfo): string => {
  return `${cycle.startAge}-${cycle.endAge}${t('purpleStarChart.years')}`;
};

const formatXiaoXianInfo = (cycle: XiaoXianInfo): string => {
  return `${cycle.age}${t('purpleStarChart.years')}`;
};

const isCurrentCycle = (cycle: DaXianInfo): boolean => {
  // TODO: 根據目前年齡判斷是否為當前大限
  // 這裡需要計算當前年齡
  return false;
};

const formatBirthDate = (): string => {
  if (!props.calculationInfo) return '';
  return new Date(props.calculationInfo.birthInfo.solarDate).toLocaleDateString();
};

const formatGender = (): string => {
  if (!props.calculationInfo) return '';
  return t(`purpleStarChart.genders.${props.calculationInfo.birthInfo.gender}`);
};

const getStarPalaceName = (star: Star): string => {
  if (!props.chartData) return '';
  const palace = props.chartData.palaces.find(p => p.index === star.palaceIndex);
  return palace?.name || '';
};

// 檢查是否為空宮（無主星）
const isEmptyPalace = (zhiName: string): boolean => {
  const palace = getPalaceByZhi(zhiName);
  if (!palace) return false;
  
  const mainStars = palace.stars.filter(star => star.type === 'main');
  return mainStars.length === 0;
};

// 獲取借星資訊
const getBorrowedPalaceInfo = (zhiName: string) => {
  const palace = getPalaceByZhi(zhiName);
  if (!palace || !isEmptyPalace(zhiName)) return undefined;
  
  // 計算對宮索引
  const oppositePalaceIndex = (palace.index + 6) % 12;
  const oppositePalace = props.chartData?.palaces.find(p => p.index === oppositePalaceIndex);
  
  if (!oppositePalace) return undefined;
  
  const mainStars = oppositePalace.stars.filter(star => star.type === 'main');
  
  return {
    name: oppositePalace.name,
    mainStars: mainStars
  };
};

const getPalaceFortuneClass = (palace?: Palace): string => {
  if (!palace || !palace.fortuneType) return '';
  
  return `palace-fortune-${palace.fortuneType}`;
};

// 根據宮位名稱返回對應的生命主題說明
const getCycleTheme = (palaceName: string): string => {
  const themes: Record<string, string> = {
    '命宮': '個人特質與基本運勢',
    '兄弟宮': '手足關係與朋友圈',
    '夫妻宮': '婚姻與伴侶關係',
    '子女宮': '後代與創造力',
    '財帛宮': '財富與物質生活',
    '疾厄宮': '健康與困境',
    '遷移宮': '居所變動與旅行',
    '交友宮': '人際關係與合作',
    '官祿宮': '事業成就與社會地位',
    '田宅宮': '不動產與居家環境',
    '福德宮': '內在幸福與精神追求',
    '父母宮': '長輩關係與根源'
  };
  
  return themes[palaceName] || '人生特定領域';
};

// 事件處理
// 切換視圖模式：簡潔/詳細
const toggleViewMode = () => {
  viewMode.value = viewMode.value === 'simple' ? 'detailed' : 'simple';
  
  // 立即應用視圖模式變化
  setTimeout(() => {
    if (viewMode.value === 'detailed') {
      // 詳細模式：顯示所有大限小限資訊
      document.querySelectorAll('.cycles-info').forEach((el) => {
        (el as HTMLElement).style.display = 'block';
      });
      // 調整網格高度以適應額外內容
      const chartGrid = document.querySelector('.chart-grid');
      if (chartGrid) {
        (chartGrid as HTMLElement).classList.add('detailed');
      }
    } else {
      // 簡潔模式：隱藏大限小限資訊
      document.querySelectorAll('.cycles-info').forEach((el) => {
        (el as HTMLElement).style.display = 'none';
      });
      // 還原網格高度
      const chartGrid = document.querySelector('.chart-grid');
      if (chartGrid) {
        (chartGrid as HTMLElement).classList.remove('detailed');
      }
    }
  }, 50);
};

// 切換顯示模式：精簡/展開
const toggleDisplayMode = () => {
  displayMode.value = displayMode.value === 'compact' ? 'expanded' : 'compact';
  
  // 立即應用顯示模式變化
  setTimeout(() => {
    if (displayMode.value === 'compact') {
      // 精簡檢視：禁用互動，縮減顯示
      document.querySelectorAll('.palace-cell').forEach((el) => {
        (el as HTMLElement).style.pointerEvents = 'none';
        (el as HTMLElement).classList.add('compact-mode');
      });
      
      // 隱藏非必要元素
      document.querySelectorAll('.star-item:not(.star-main)').forEach((el) => {
        (el as HTMLElement).style.opacity = '0.5';
      });
    } else {
      // 展開檢視：啟用互動，完整顯示
      document.querySelectorAll('.palace-cell').forEach((el) => {
        (el as HTMLElement).style.pointerEvents = 'auto';
        (el as HTMLElement).classList.remove('compact-mode');
      });
      
      // 恢復所有星曜顯示
      document.querySelectorAll('.star-item').forEach((el) => {
        (el as HTMLElement).style.opacity = '1';
      });
    }
  }, 50);
};

const handlePalaceClick = (position: string) => {
  if (position === 'center') return;
  const palace = getPalaceByZhi(position);
  if (palace) {
    selectedPalace.value = palace;
    emit('palaceClick', palace);
  }
};

const handleStarClick = (star: Star) => {
  selectedStar.value = star;
  emit('starClick', star);
};

const closeStarDetail = () => {
  selectedStar.value = null;
};

// FortuneOverview 相關事件處理
const handleFortuneOverviewPalaceClick = (palaceIndex: number) => {
  console.log(`正在導航到宮位 ${palaceIndex}`);
  
  // 滾動到對應的宮位並高亮
  const palace = props.chartData?.palaces.find(p => p.index === palaceIndex);
  if (palace) {
    console.log(`找到宮位: ${palace.name} (${palace.zhi})`);
    
    // 使用多種選擇器嘗試找到宮位元素
    let palaceElement = document.querySelector(`[data-palace-zhi="${palace.zhi}"]`);
    if (!palaceElement) {
      palaceElement = document.querySelector(`[data-palace-index="${palaceIndex}"]`);
    }
    if (!palaceElement) {
      palaceElement = document.querySelector(`.palace-${palace.zhi}`);
    }
    
    if (palaceElement) {
      console.log('找到宮位元素，開始滾動和高亮');
      
      // 先移除任何現有的高亮
      document.querySelectorAll('.palace-highlight').forEach(el => {
        el.classList.remove('palace-highlight');
      });
      
      // 滾動到宮位
      palaceElement.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center',
        inline: 'center'
      });
      
      // 添加高亮效果
      palaceElement.classList.add('palace-highlight');
      
      // 設置選中的宮位
      selectedPalace.value = palace;
      
      // 3秒後移除高亮
      setTimeout(() => {
        palaceElement.classList.remove('palace-highlight');
      }, 3000);
      
      // 發送宮位點擊事件
      emit('palaceClick', palace);
    } else {
      console.warn(`無法找到宮位 ${palace.name} (${palace.zhi}) 的 DOM 元素`);
      // 仍然設置選中的宮位並發送事件
      selectedPalace.value = palace;
      emit('palaceClick', palace);
    }
  } else {
    console.warn(`無法找到索引為 ${palaceIndex} 的宮位資料`);
  }
};

const handleStrengthClick = (strength: any) => {
  console.log('優勢點擊:', strength);
  handleFortuneOverviewPalaceClick(strength.palaceIndex);
};

const handleChallengeClick = (challenge: any) => {
  console.log('挑戰點擊:', challenge);
  handleFortuneOverviewPalaceClick(challenge.palaceIndex);
};

// 移除匯出功能

// 解讀相關方法

const setActiveDomain = (domain: 'career' | 'wealth' | 'marriage' | 'health' | 'education' | 'social') => {
  activeDomain.value = domain;
};

const setActivePalace = (palaceName: string) => {
  activePalaceName.value = palaceName;
};

const getDomainDisplayName = (domain: string): string => {
  const displayNames: Record<string, string> = {
    'career': '事業分析',
    'wealth': '財富分析',
    'marriage': '婚姻分析',
    'health': '健康分析',
    'education': '學業分析',
    'social': '人際分析'
  };
  return displayNames[domain] || domain;
};

const getFortuneDisplayName = (fortune: string): string => {
  const displayNames: Record<string, string> = {
    'excellent': '極佳',
    'good': '良好',
    'neutral': '中性',
    'challenging': '挑戰',
    'difficult': '困難'
  };
  return displayNames[fortune] || fortune;
};

// 生命週期
onMounted(() => {
  // 設置為最詳細展開模式
  const chartGrid = document.querySelector('.chart-grid');
  
  // 清除所有深度相關的類
  document.querySelectorAll('.palace-cell').forEach((el) => {
    (el as HTMLElement).classList.remove('depth-minimal', 'depth-compact', 'depth-standard', 'depth-comprehensive');
    (el as HTMLElement).classList.add('depth-comprehensive');
  });
  
  if (chartGrid) {
    (chartGrid as HTMLElement).classList.remove('simple');
    (chartGrid as HTMLElement).classList.add('detailed');
  }
  
  // 顯示所有大限小限資訊
  document.querySelectorAll('.cycles-info').forEach((el) => {
    (el as HTMLElement).style.display = 'block';
  });
  
  // 顯示所有星曜
  document.querySelectorAll('.star-item').forEach((el) => {
    (el as HTMLElement).style.opacity = '1';
  });
  
  // 啟用宮位互動
  document.querySelectorAll('.palace-cell').forEach((el) => {
    (el as HTMLElement).style.pointerEvents = 'auto';
  });
});

// 監聽
watch(() => props.chartData, (newData) => {
  if (newData) {
    // 重置選中狀態
    selectedStar.value = null;
    
    // 設置默認解讀模式
    interpretationMode.value = 'fortune';
    
    // 設置默認領域和宮位
    if (newData.domainAnalyses && newData.domainAnalyses.length > 0) {
      activeDomain.value = newData.domainAnalyses[0].domain;
    }
    
    if (newData.palaceInterpretations && newData.palaceInterpretations.length > 0) {
      activePalaceName.value = newData.palaceInterpretations[0].palaceName;
    }
  }
});

// 暴露方法給父組件使用
defineExpose({
  handleFortuneOverviewPalaceClick,
  handleStrengthClick,
  handleChallengeClick
});
</script>

<style scoped>
.purple-star-chart-container {
  width: 100%;
  max-width: 1000px;
  margin: 0 auto;
  font-family: 'Microsoft YaHei', 'SimHei', sans-serif;
}

/* 載入和錯誤狀態 */
.loading-state, .error-state {
  text-align: center;
  padding: 40px 20px;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error-icon {
  font-size: 3rem;
  margin-bottom: 15px;
}

.retry-button {
  background: #3498db;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  margin-top: 15px;
}

.retry-button:hover {
  background: #2980b9;
}

/* 圖表標題區域 */
.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
  padding: 16px;
  background: #f8f9fa;
  border-radius: 8px;
  gap: 20px;
}

.chart-header h2 {
  margin: 0;
  color: #2c3e50;
  flex: 1;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.guide-button {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 20px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.3s ease;
  box-shadow: 0 2px 6px rgba(102, 126, 234, 0.3);
}

.guide-button:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.guide-icon {
  font-size: 16px;
}

.view-toggle-button, .export-button {
  padding: 8px 16px;
  border: 2px solid #3498db;
  background: white;
  color: #3498db;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s;
}

.view-toggle-button.active,
.view-toggle-button:hover,
.display-toggle-button.active,
.display-toggle-button:hover,
.export-button:hover,
.depth-tab-button.active,
.depth-tab-button:hover {
  background: #3498db;
  color: white;
}

/* 顯示深度容器與標籤 
.display-depth-container {
  background: #f0f8ff;
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 10px;
}
*/
.mode-help-text {
  margin-bottom: 10px;
  color: #2c3e50;
  font-size: 0.9rem;
  font-weight: 500;
}

.display-depth-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-bottom: 10px;
}

.depth-tab-button {
  padding: 8px 16px;
  border: 2px solid #3498db;
  background: white;
  color: #3498db;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 0.9rem;
}

.depth-description {
  margin-top: 10px;
  padding: 8px 12px;
  background: white;
  border-radius: 5px;
  color: #495057;
  font-size: 0.85rem;
  border-left: 3px solid #3498db;
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-5px); }
  to { opacity: 1; transform: translateY(0); }
}

/* 深度相關樣式 */
.palace-cell.depth-minimal {
  padding: 4px;
}

.palace-cell.depth-comprehensive {
  padding: 10px;
}

@media (max-width: 768px) {
  .chart-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
    padding: 12px;
  }
  
  .chart-header h2 {
    font-size: 1.2rem;
  }
  
  .header-actions {
    width: 100%;
    justify-content: center;
  }
  
  /* intro-card 響應式優化 */
  .features-grid {
    grid-template-columns: 1fr;
    gap: 16px;
  }
  
  .feature-item {
    padding: 16px;
    min-height: 100px;
  }
  
  .intro-card {
    padding: 20px;
  }
  
  .intro-card h3 {
    font-size: 18px;
    margin-bottom: 20px;
  }
  
  .feature-content h4 {
    font-size: 15px;
  }
  
  .feature-content p {
    font-size: 13px;
  }
  
  .learn-more-button {
    padding: 10px 24px;
    font-size: 13px;
    min-width: 120px;
  }
}

/* 簡要解讀區域 */
.chart-summary {
  margin-bottom: 20px;
  padding: 20px;
  background: #f0f8ff;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.05);
}

.summary-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.summary-header h3 {
  margin: 0;
  color: #2c3e50;
  font-size: 1.2rem;
}

.toggle-summary-button {
  background: none;
  border: 1px solid #3498db;
  color: #3498db;
  padding: 4px 10px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.85rem;
  transition: all 0.3s;
}

.toggle-summary-button:hover {
  background: #3498db;
  color: white;
}

.summary-content {
  position: relative;
}

.summary-features {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 15px;
}

.feature-item {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.feature-icon {
  color: #3498db;
  font-size: 1.1rem;
}

.feature-text {
  color: #333;
  line-height: 1.5;
}

.summary-detailed {
  background: white;
  padding: 15px;
  border-radius: 6px;
  border-left: 4px solid #3498db;
  margin-bottom: 10px;
}

.summary-detailed p {
  margin: 0;
  line-height: 1.6;
  color: #333;
}

.interaction-hint {
  margin-top: 15px;
}

.hint-content {
  display: flex;
  align-items: center;
  gap: 10px;
  background: rgba(52, 152, 219, 0.1);
  padding: 10px 15px;
  border-radius: 6px;
  border: 1px dashed #3498db;
}

.hint-icon {
  font-size: 1.2rem;
  color: #3498db;
}

.hint-text-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.hint-text {
  color: #555;
  font-weight: 500;
}

.swipe-hint {
  color: #666;
  font-size: 0.85rem;
  display: flex;
  align-items: center;
  gap: 5px;
}

.swipe-arrow {
  animation: swipeAnimation 2s infinite ease-in-out;
  display: inline-block;
  margin-left: 4px;
}

@keyframes swipeAnimation {
  0% { transform: translate(-3px, -3px); }
  25% { transform: translate(3px, -3px); }
  50% { transform: translate(3px, 3px); }
  75% { transform: translate(-3px, 3px); }
  100% { transform: translate(-3px, -3px); }
}

.close-hint {
  background: none;
  border: none;
  color: #999;
  font-size: 1rem;
  cursor: pointer;
  padding: 0;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-hint:hover {
  color: #333;
}

/* 重新展開按鈕樣式 */
.show-summary-button-container {
  margin-bottom: 20px;
  text-align: center;
}

.show-summary-button {
  background: #3498db;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s;
  font-weight: 500;
}

.show-summary-button:hover {
  background: #2980b9;
  transform: translateY(-1px);
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}


/* 命盤網格 */
.chart-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, minmax(120px, auto));
  gap: 2px;
  border: 2px solid #2c3e50;
  background: #2c3e50;
  border-radius: 8px;
  overflow: auto;
  max-width: 100%;
  max-height: 80vh;
}

.chart-grid.detailed {
  grid-template-rows: repeat(4, minmax(170px, auto));
}

.palace-cell {
  background: white;
  padding: 8px;
  position: relative;
  cursor: pointer;
  transition: background-color 0.3s;
}

.palace-cell:hover:not(.center-position) {
  background: #f8f9fa;
}

/* 中央太極 */
.palace-center {
  grid-column: 2 / span 2;
  grid-row: 2 / span 2;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: linear-gradient(45deg, #f8f9fa, #e9ecef);
  border: 1px solid #dee2e6;
  cursor: default;
}

.palace-center h4 {
  margin: 0 0 10px 0;
  color: #2c3e50;
  font-size: 1.1rem;
}

.center-info p {
  margin: 3px 0;
  font-size: 0.9rem;
  color: #555;
}

/* 宮位內容 */
.palace-content {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.palace-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  padding-bottom: 5px;
  border-bottom: 1px solid #eee;
}

.palace-name {
  font-weight: bold;
  color: #2c3e50;
  font-size: 0.9rem;
}

.palace-zhi {
  background: #e9ecef;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 0.8rem;
  color: #495057;
}

.ming-indicator, .shen-indicator {
  background: #dc3545;
  color: white;
  padding: 1px 4px;
  border-radius: 2px;
  font-size: 0.7rem;
  font-weight: bold;
}

.shen-indicator {
  background: #28a745;
}

/* 星曜容器 */
.stars-container {
  flex: 1;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  align-content: flex-start;
}

.star-item {
  display: inline-flex;
  align-items: center;
  padding: 3px 6px;
  border-radius: 4px;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.3s;
  border: 1px solid transparent;
}

.star-item:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.star-name {
  margin-right: 3px;
}

.transformations {
  font-size: 0.75rem;
  font-weight: bold;
  display: flex;
  gap: 2px;
}

.transformations.detailed-transformations {
  gap: 3px;
}

.transformations.detailed-transformations span {
  padding: 1px 3px;
  border-radius: 3px;
  font-size: 0.7rem;
  font-weight: bold;
}

.transformation-祿 {
  background-color: #ffc107;
  color: #212529;
}

.transformation-權 {
  background-color: #17a2b8;
  color: white;
}

.transformation-科 {
  background-color: #28a745;
  color: white;
}

.transformation-忌 {
  background-color: #dc3545;
  color: white;
}

/* 星曜類型樣式 */
.star-main {
  background: #fff3cd;
  color: #856404;
  border-color: #ffeaa7;
  font-weight: bold;
}

.star-auxiliary {
  background: #d1ecf1;
  color: #0c5460;
  border-color: #bee5eb;
}

.star-minor {
  background: #d4edda;
  color: #155724;
  border-color: #c3e6cb;
}

/* 星曜類型標記樣式 */
.star-type-badge {
  font-size: 8px;
  padding: 1px 3px;
  border-radius: 2px;
  margin-left: 2px;
  font-weight: bold;
  color: white;
}

.star-type-badge.minor {
  background: #9c27b0;
  color: white;
}

/* 四化樣式 */
.transform-祿 {
  background: #fff3cd !important;
  color: #856404 !important;
  border-color: #ffeaa7 !important;
}

.transform-權 {
  background: #d4edda !important;
  color: #155724 !important;
  border-color: #c3e6cb !important;
}

.transform-科 {
  background: #d1ecf1 !important;
  color: #0c5460 !important;
  border-color: #bee5eb !important;
}

.transform-忌 {
  background: #f8d7da !important;
  color: #721c24 !important;
  border-color: #f5c6cb !important;
}

/* 星曜屬性樣式 */
.star-attribute {
  font-size: 0.7rem;
  margin-left: 3px;
  padding: 1px 3px;
  border-radius: 2px;
}

.attribute-吉 {
  background: #d4edda;
  color: #155724;
}

.attribute-凶 {
  background: #f8d7da;
  color: #721c24;
}

.attribute-中性 {
  background: #e2e3e5;
  color: #383d41;
}

/* 宮位吉凶樣式 */
.fortune-indicator {
  font-size: 0.7rem;
  padding: 1px 3px;
  border-radius: 2px;
  margin-left: 3px;
}

.fortune-吉 {
  background: #d4edda;
  color: #155724;
}

.fortune-凶 {
  background: #f8d7da;
  color: #721c24;
}

.fortune-中性 {
  background: #e2e3e5;
  color: #383d41;
}

/* 宮位吉凶背景色 */
.palace-fortune-吉 {
  background-color: rgba(212, 237, 218, 0.1);
}

.palace-fortune-凶 {
  background-color: rgba(248, 215, 218, 0.1);
}

.palace-fortune-中性 {
  background-color: rgba(226, 227, 229, 0.1);
}

/* 大小限資訊 */
.cycles-info {
  margin-top: 8px;
  padding-top: 5px;
  border-top: 1px solid #eee;
}

.da-xian-info, .xiao-xian-info {
  margin: 2px 0;
}

.da-xian-info small {
  color: #dc3545;
  font-weight: 500;
}

.xiao-xian-info small {
  color: #28a745;
  font-weight: 500;
}

/* 大限詳細資訊 */
.cycles-detail {
  margin-top: 30px;
  margin-bottom: 30px;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 8px;
}

.cycles-detail-header {
  margin-bottom: 20px;
}

.cycles-detail-header h3 {
  margin: 0 0 15px 0;
  color: #2c3e50;
}

.cycles-explanation {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: rgba(52, 152, 219, 0.1);
  padding: 15px;
  border-radius: 6px;
  margin-bottom: 15px;
}

.info-icon {
  font-size: 1.2rem;
  color: #3498db;
  flex-shrink: 0;
}

.info-text {
  font-size: 0.95rem;
  line-height: 1.5;
  color: #444;
}

.cycles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 15px;
}

.cycle-item {
  padding: 10px;
  background: white;
  border: 1px solid #dee2e6;
  border-radius: 5px;
  text-align: center;
}

.cycle-item.current {
  border-color: #3498db;
  background: #e3f2fd;
}

.cycle-header {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.cycle-age {
  font-weight: bold;
  color: #2c3e50;
}

.cycle-palace {
  color: #555;
  font-size: 0.9rem;
}

.cycle-zhi {
  margin-top: 5px;
  padding: 3px 6px;
  background: #e9ecef;
  border-radius: 3px;
  font-size: 0.8rem;
}

.cycle-description {
  margin-top: 8px;
  font-size: 0.85rem;
  line-height: 1.4;
  color: #555;
  text-align: left;
  padding: 5px;
  border-top: 1px solid #eee;
}

.palace-cell.compact-mode {
  padding: 4px;
  transition: all 0.3s;
}

.compact-mode .palace-header {
  margin-bottom: 4px;
  padding-bottom: 3px;
}

.compact-mode .palace-name {
  font-size: 0.8rem;
}

.compact-mode .palace-zhi {
  font-size: 0.7rem;
  padding: 1px 4px;
}

/* 星曜詳細資訊彈窗 */
.star-detail-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 0;
  border-radius: 8px;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #eee;
}

.modal-header h3 {
  margin: 0;
  color: #2c3e50;
}

.close-button {
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #999;
  padding: 0;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-button:hover {
  color: #333;
}

.modal-body {
  padding: 20px;
}

.modal-body p {
  margin: 10px 0;
}

.modal-body ul {
  margin: 10px 0;
  padding-left: 20px;
}

/* 星曜屬性標籤 */
.star-attributes-section {
  margin: 15px 0;
  padding: 10px;
  background: #f8f9fa;
  border-radius: 5px;
}

.attribute-item {
  margin: 8px 0;
}

.attribute-tag {
  display: inline-block;
  padding: 3px 8px;
  margin-left: 5px;
  border-radius: 3px;
  background-color: #e9ecef;
  color: #212529;
  font-size: 0.9rem;
}

.attribute-tag.attribute-吉 {
  background-color: #d4edda;
  color: #155724;
}

.attribute-tag.attribute-凶 {
  background-color: #f8d7da;
  color: #721c24;
}

.attribute-tag.attribute-中性 {
  background-color: #e2e3e5;
  color: #383d41;
}

.star-description {
  margin: 15px 0;
  padding: 10px;
  border-left: 3px solid #ddd;
  background-color: #f9f9f9;
}

.star-description p {
  margin: 5px 0 0 0;
  font-size: 0.95rem;
  line-height: 1.5;
  color: #333;
}


/* 空宮指示器樣式 */
.empty-palace-indicator {
  margin-bottom: 8px;
}

/* 年齡分段資訊樣式 */
.cycles-info {
  margin-top: 12px;
  margin-bottom: 4px;
  padding: 6px 8px;
  background: rgba(248, 249, 250, 0.8);
  border-radius: 4px;
  border: 1px solid rgba(0, 0, 0, 0.1);
}

.da-xian-info, .xiao-xian-info {
  margin: 3px 0;
  font-size: 0.8rem;
  color: #555;
  line-height: 1.3;
}

.da-xian-info {
  font-weight: 500;
  color: #2c3e50;
}

/* 特徵提示樣式 */
.feature-hints {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  min-height: 24px;
  position: relative;
  z-index: 1;
}

.interpretation-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 15px;
}

.interpretation-header h3 {
  margin: 0;
  color: #2c3e50;
}

.interpretation-tabs {
  display: flex;
  gap: 10px;
}

.tab-button {
  padding: 8px 16px;
  border: 2px solid #3498db;
  background: white;
  color: #3498db;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s;
}

.tab-button.active,
.tab-button:hover {
  background: #3498db;
  color: white;
}

/* 綜合解讀樣式 */
.comprehensive-interpretation {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.interpretation-card {
  background: white;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.interpretation-card h4 {
  margin: 0 0 10px 0;
  color: #2c3e50;
  border-bottom: 1px solid #eee;
  padding-bottom: 8px;
}

.interpretation-card p {
  margin: 0;
  line-height: 1.6;
  color: #333;
}

.interpretation-card ul {
  margin: 0;
  padding-left: 20px;
  line-height: 1.6;
}

.lifecycle-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 10px;
  margin-top: 15px;
}

.lifecycle-item {
  background: #f9f9f9;
  border-radius: 5px;
  padding: 10px;
  border-left: 3px solid #3498db;
}

.lifecycle-period {
  font-weight: bold;
  color: #2c3e50;
}

.lifecycle-content {
  margin-top: 5px;
}

.lifecycle-theme {
  color: #e74c3c;
  font-weight: 500;
}

.lifecycle-focus {
  color: #555;
  font-size: 0.9em;
  margin-top: 3px;
}

/* 領域分析樣式 */
.domain-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 20px;
}

.domain-tab-button {
  padding: 8px 16px;
  border: none;
  background: #e9ecef;
  color: #495057;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s;
}

.domain-tab-button.active,
.domain-tab-button:hover {
  background: #3498db;
  color: white;
}

.domain-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.domain-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.domain-header h4 {
  margin: 0;
  color: #2c3e50;
}

.fortune-badge {
  padding: 5px 10px;
  border-radius: 15px;
  font-size: 0.85rem;
  font-weight: 500;
}

.fortune-excellent {
  background: #d4edda;
  color: #155724;
}

.fortune-good {
  background: #cce5ff;
  color: #004085;
}

.fortune-neutral {
  background: #e2e3e5;
  color: #383d41;
}

.fortune-challenging {
  background: #fff3cd;
  color: #856404;
}

.fortune-difficult {
  background: #f8d7da;
  color: #721c24;
}

.domain-content h5 {
  margin: 15px 0 10px 0;
  color: #2c3e50;
  border-bottom: 1px solid #eee;
  padding-bottom: 5px;
}

.domain-content ul {
  margin: 0;
  padding-left: 20px;
  line-height: 1.6;
}

.domain-periods {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-top: 15px;
}

.periods-column h5 {
  margin-top: 0;
}

/* 宮位解讀樣式 */
.palace-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 20px;
}

.palace-tab-button {
  padding: 8px 16px;
  border: none;
  background: #e9ecef;
  color: #495057;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s;
}

.palace-tab-button.active,
.palace-tab-button:hover {
  background: #3498db;
  color: white;
}

.palace-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.palace-content h4 {
  margin: 0 0 20px 0;
  color: #2c3e50;
  border-bottom: 1px solid #eee;
  padding-bottom: 10px;
}

.palace-section {
  margin-bottom: 20px;
}

.palace-section h5 {
  margin: 0 0 10px 0;
  color: #2c3e50;
}

.trait-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.trait-tag {
  background: #e9ecef;
  padding: 5px 10px;
  border-radius: 15px;
  font-size: 0.85rem;
}

.palace-section ul {
  margin: 0;
  padding-left: 20px;
  line-height: 1.6;
}

/* 響應式設計優化 */
/* 大螢幕 (桌機) */
@media (min-width: 1200px) {
  .chart-grid {
    max-width: 900px;
    margin: 0 auto;
  }
  
  .interpretation-section {
    max-width: 1000px;
    margin-left: auto;
    margin-right: auto;
  }
}

/* 中等螢幕 (平板橫向) */
@media (max-width: 1024px) {
  .chart-grid {
    max-width: 100%;
  }
  
  .comprehensive-interpretation {
    grid-template-columns: 1fr;
  }
  
  .domain-periods {
    grid-template-columns: 1fr;
  }
}

/* 平板直向 */
@media (max-width: 768px) {
  .chart-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
    padding: 12px;
  }
  
  .chart-header h2 {
    font-size: 1.2rem;
  }
  
  .header-actions {
    width: 100%;
    justify-content: center;
  }
  
  .guide-button {
    font-size: 13px;
    padding: 6px 16px;
  }
  
  .chart-grid {
    grid-template-rows: repeat(4, minmax(100px, auto));
    gap: 1px;
  }
  
  .chart-grid.detailed {
    grid-template-rows: repeat(4, minmax(160px, auto));
  }
  
  .palace-cell {
    padding: 6px;
    font-size: 0.9rem;
  }
  
  .palace-header {
    flex-wrap: wrap;
    gap: 4px;
  }
  
  .palace-name {
    font-size: 0.85rem;
  }
  
  .palace-zhi {
    font-size: 0.75rem;
  }
  
  .star-item {
    font-size: 0.8rem;
    padding: 2px 4px;
  }
  
  .star-name {
    font-size: 0.8rem;
  }

  /* 特徵提示響應式樣式 */
  .feature-hints {
    margin-top: 6px;
    padding-top: 6px;
    min-height: 20px;
  }

  /* 年齡分段資訊響應式樣式 */
  .cycles-info {
    margin-top: 8px;
    margin-bottom: 2px;
    padding: 4px 6px;
  }
  
  .da-xian-info, .xiao-xian-info {
    font-size: 0.75rem;
    margin: 2px 0;
  }
  
  .interpretation-section {
    margin-top: 20px;
    padding: 16px;
  }
  
  
  .cycles-grid {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  }
}

/* 手機螢幕 */
@media (max-width: 480px) {
  .purple-star-chart-container {
    padding: 8px;
  }
  
  .chart-header {
    padding: 8px;
  }
  
  .chart-header h2 {
    font-size: 1.1rem;
  }
  
  .guide-button {
    font-size: 12px;
    padding: 6px 12px;
  }
  
  .chart-grid {
    grid-template-rows: repeat(4, minmax(80px, auto));
    gap: 1px;
  }
  
  .palace-cell {
    padding: 4px;
    font-size: 0.8rem;
  }
  
  .palace-center {
    padding: 8px;
  }
  
  .center-info p {
    font-size: 0.8rem;
  }
  
  .palace-name {
    font-size: 0.8rem;
  }
  
  .palace-zhi {
    font-size: 0.7rem;
    padding: 1px 4px;
  }
  
  .star-item {
    font-size: 0.75rem;
    padding: 1px 3px;
    margin: 1px;
  }
  
  .star-name {
    font-size: 0.75rem;
  }
  
  .transformations {
    font-size: 0.65rem;
  }
  
  .star-attribute {
    font-size: 0.6rem;
    padding: 1px 2px;
  }
  
  .interpretation-section {
    padding: 12px;
  }
  
  .interpretation-header {
    flex-direction: column;
    gap: 12px;
  }
  
  .interpretation-tabs {
    justify-content: stretch;
  }
  
  .tab-button {
    flex: 1;
    font-size: 12px;
    padding: 8px 4px;
    text-align: center;
  }
  
  .interpretation-card {
    padding: 12px;
  }
  
  .lifecycle-grid {
    grid-template-columns: 1fr;
  }
  
  .domain-tabs {
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
  
  .palace-tabs {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
  
}

/* 極小螢幕 */
@media (max-width: 360px) {
  .chart-grid {
    grid-template-rows: repeat(4, minmax(70px, auto));
  }
  
  .palace-cell {
    padding: 3px;
  }
  
  .star-item {
    font-size: 0.7rem;
    padding: 1px 2px;
  }
  
}

/* 宮位高亮動畫 */
.palace-highlight {
  animation: highlightPulse 3s ease-in-out;
  border: 3px solid #667eea !important;
  box-shadow: 0 0 25px rgba(102, 126, 234, 0.7) !important;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.15), rgba(118, 75, 162, 0.1)) !important;
  transform: scale(1.02) !important;
  z-index: 10 !important;
  position: relative !important;
}

.palace-highlight .palace-content {
  background: rgba(255, 255, 255, 0.95) !important;
  border-radius: 8px;
}

@keyframes highlightPulse {
  0% {
    border-color: #667eea;
    box-shadow: 0 0 15px rgba(102, 126, 234, 0.5);
    transform: scale(1.02);
  }
  25% {
    border-color: #764ba2;
    box-shadow: 0 0 35px rgba(118, 75, 162, 0.8);
    transform: scale(1.05);
  }
  50% {
    border-color: #f093fb;
    box-shadow: 0 0 40px rgba(240, 147, 251, 0.9);
    transform: scale(1.05);
  }
  75% {
    border-color: #764ba2;
    box-shadow: 0 0 35px rgba(118, 75, 162, 0.8);
    transform: scale(1.05);
  }
  100% {
    border-color: #667eea;
    box-shadow: 0 0 15px rgba(102, 126, 234, 0.5);
    transform: scale(1.02);
  }
}
</style>
