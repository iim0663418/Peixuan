// 全局類型聲明
declare global {
  interface Window {
    Solar: any;
    Lunar: any;
    LunarMonth: any;
  }
}

export {};
