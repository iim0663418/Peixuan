# Peixuan 專案進度

**專案**: 佩璇 - 智能命理分析平台
**當前階段**: Phase 1 實作中 - 數學化核心重構
**最後更新**: 2025-11-30

---

## 🎉 重大里程碑

### ✅ Phase 1 - Sprint 1: 核心基礎 - 完成 (2025-11-30)

#### Task 1.3: 五行關係模組 (WuXing Relations Module)
- **狀態**: ✅ 完成

**交付檔案**:
- ✅ `wuXing/relations.ts` - 五行生剋關係計算 + 干支五行映射
- ✅ `wuXing/index.ts` - 模組匯出
- ✅ `relations.test.ts` - 完整5x5矩陣驗證 + 干支映射測試

**技術細節**:
- 實現五行生剋完整矩陣 (5x5)
  - `produce` (我生): (index + 1) % 5
  - `overcome` (我克): (index + 2) % 5
  - `produced` (生我): (index + 4) % 5
  - `overcomed` (克我): (index + 3) % 5
  - `same` (同類): index === index
- 天干五行映射: 甲乙木、丙丁火、戊己土、庚辛金、壬癸水
- 地支五行映射: 寅卯木、巳午火、辰戌丑未土、申酉金、亥子水
- 類型安全: WuXing 與 WuXingRelation 類型定義

**測試覆蓋**:
- 5x5 完整關係矩陣驗證 (25組測試)
- 10天干五行映射完整測試
- 12地支五行映射完整測試
- 整合測試: 干支五行關係推導

---

### ✅ Phase 1 - Sprint 1: 核心基礎 - Task 1.1 & 1.2 完成 (2025-11-30)

#### Task 1.1: 時間校正模組 (Time Correction Module)
- **狀態**: ✅ 完成

**交付檔案**:
- ✅ `trueSolarTime.ts` - 真太陽時計算 (經度校正 + 均時差)
- ✅ `julianDay.ts` - 儒略日轉換 (雙向)
- ✅ `solarTerms.ts` - 節氣查詢 (整合 lunar-typescript)
- ✅ `trueSolarTime.test.ts` - 單元測試 (北京、台北案例)

**技術細節**:
- 實現公式: `T_true = T_clock + ΔT_long + EoT`
- 經度校正: `(L_local - L_std) × 4 分鐘`
- 均時差: 基於研究文件 §1.1.1 公式
- 儒略日: 用於日柱計算 `I_day = (JDN - 10) mod 60`

#### Task 1.2: 干支模運算模組 (GanZhi Modulo Arithmetic Module)
- **狀態**: ✅ 完成

**交付檔案**:
- ✅ `ganZhi/conversion.ts` - 60甲子週期轉換 (indexToGanZhi, ganZhiToIndex)
- ✅ `ganZhi/modulo.ts` - 模運算工具 (stemModulo mod 10, branchModulo mod 12)
- ✅ `ganZhi/index.ts` - 模組匯出
- ✅ `conversion.test.ts` - 完整60甲子週期驗證

**技術細節**:
- 使用中國剩餘定理 (Chinese Remainder Theorem) 實現干支互轉
- 天干: 10元素循環 (甲乙丙丁戊己庚辛壬癸)
- 地支: 12元素循環 (子丑寅卯辰巳午未申酉戌亥)
- 支援負數索引與大於60的索引 (模運算正規化)

### ✅ Phase 2: 紫微斗數計算邏輯實現 (2025-11-29)
- **核心功能**: 完整計算邏輯 (681 lines)
- **Commits**: b2c7059 → c1787b5 (7 commits)
- **狀態**: ✅ 生產環境運行中

**關鍵成果**:
- ✅ API 200 OK
- ✅ 12 宮位 + 大限 + 小限 + 五行局
- ✅ 中文數字支援 (火六局)
- ✅ 命宮天干 (mingGan)
- ✅ CI 編譯步驟

### ✅ 專案架構審計 (2025-11-29)
- **文檔**: PROJECT_AUDIT_2025-11-29.md
- **架構圖**: ARCHITECTURE_CURRENT.md
- **狀態**: ✅ 完整梳理

**關鍵發現**:
- ⚠️ 代碼重複: 前端 ziweiCalc.ts (683 lines) 未使用
- ✅ 前後端職責清晰
- ✅ 核心功能完整

### ✅ Week 1 程式碼品質優化 (2025-11-29)
- v-for :key 覆蓋率: 100%
- ESLint 問題: 840 → 467 (-44.4%)
- 錯誤數: 421 → 93 (-77.9%)

---

## 🎯 當前狀態

### 生產環境
- **URL**: https://peixuan-worker.csw30454.workers.dev
- **架構**: Cloudflare Workers + D1 + Vue 3 PWA
- **狀態**: ✅ 運行中

### API 端點
- ✅ POST /api/v1/purple-star/calculate (紫微斗數計算)
- ✅ GET/POST /api/charts (命盤 CRUD)
- ✅ GET/POST /api/analyses (分析 CRUD)
- ✅ GET /health (健康檢查)

### 計算邏輯
- ✅ 八字: 前端本地 (baziCalc.ts 1,146 lines)
- ✅ 紫微: Worker 後端 (purpleStarCalculation.ts 681 lines)
- ⚠️ 重複: 前端 ziweiCalc.ts (683 lines) 未使用

---

## 📝 已知問題

### 代碼重複
- 前端 ziweiCalc.ts (683 lines) 無任何引用
- 建議: Week 2 移除（選項 A）

### 功能缺失（從未實現）
- 四化飛星頂層彙總
- 流年太歲計算

### ESLint 狀態
- 錯誤: 93
- 警告: 374
- 可自動修復: 95

---

## 🔄 分支狀態
- **main**: 生產部署 (最新: c1787b5)

---

### ⚠️ Sprint B Task B3: 移除舊計算邏輯 - BLOCKED (2025-11-30)

**任務狀態**: ❌ **無法安全執行 - 需先完成 Task B2**

**發現**:
- ❌ `baziCalc.ts` (1,146 lines) 仍被 **7個組件** 主動使用
- ⚠️ `ziweiCalc.ts` (683 lines) 僅被測試文件使用 (可刪除)
- ✅ 新的統一系統已創建 (`unifiedApiService.ts`, `UnifiedInputForm.vue`)
- ❌ 新系統**尚未整合**到前端路由或任何視圖中

**依賴文件**:
- `BaziChart.vue`, `BaziChartDisplay.vue`, `ElementsChart.vue`
- `YearlyFateTimeline.vue`, `UserInputForm.vue`
- `BaziView.vue`, `yearlyInteractionUtils.ts`

**建議行動**:
1. ⏸️ **暫停 Task B3** 直到 Task B2 完成
2. 🔧 **優先執行**: 將 UnifiedInputForm 整合到路由
3. 🧪 **創建平行系統**: 新舊系統並行運行
4. ✅ **驗證後再刪除**: 確保新系統完全可用

**可安全刪除** (低風險):
- ✅ `ziweiCalc.ts` - 僅測試文件引用
- ✅ `ziweiCalc.spec.ts` - 測試文件

**NOT SAFE** (高風險 - 會破壞生產環境):
- ❌ `baziCalc.ts` - 核心計算邏輯仍在使用

---

### Task R4.4: API 整合至 UnifiedCalculator - ✅ 完成 (2025-11-30 14:01)
- **狀態**: ✅ 完成
- **執行時間**: 2 小時（預估）

**修改檔案**:
- ✅ `peixuan-worker/src/calculation/types/index.ts` (+30 lines)
- ✅ `peixuan-worker/src/calculation/integration/calculator.ts` (+28 lines)

**變更內容**:
1. **types/index.ts**:
   - 導入 StemCombination, BranchClash, HarmoniousCombination 類型
   - 擴展 CalculationResult 介面: `annualFortune?: { annualPillar, annualLifePalaceIndex, interactions }`

2. **calculator.ts**:
   - 導入 getAnnualPillar (annual/liuchun)
   - 導入 locateAnnualLifePalace (annual/palace)
   - 導入 detectStemCombinations, detectBranchClashes, detectHarmoniousCombinations (annual/interaction)
   - 在 calculate() 中調用流年計算
   - 使用當前日期作為查詢日期
   - 整合大運地支至三合/三會檢測

**整合流程**:
1. 驗證輸入
2. 計算八字（四柱、藏干、十神、五行分布、大運）
3. 計算紫微（命宮、身宮、五行局、星曜）
4. **計算流年**（新增）:
   - 獲取流年干支（考慮立春交接）
   - 定位流年命宮在紫微盤上的位置
   - 檢測天干五合
   - 檢測地支六沖（含嚴重度分級）
   - 檢測三合/三會（含大運地支）
5. 返回統一結果

**驗收標準**:
- ✅ CalculationResult 包含 annualFortune 欄位
- ✅ annualFortune 包含 annualPillar、annualLifePalaceIndex、interactions
- ✅ interactions 包含 stemCombinations、branchClashes、harmoniousCombinations
- ✅ POST /api/v1/calculate 返回完整流年數據
- ✅ TypeScript 編譯通過

---

## Sprint R4: 流年計算 - ✅ 完成 (2025-11-30)

**總結**:
- Task R4.1: 流年干支與立春交接 ✅
- Task R4.2: 流年命宮定位 ✅
- Task R4.3: 流年交互矩陣 ✅
- Task R4.4: API 整合至 UnifiedCalculator ✅

**交付成果**:
- 3 個新檔案（liuchun.ts, palace.ts, interaction.ts）
- 3 個測試檔案（liuchun.test.ts, palace.test.ts, interaction.test.ts）
- 2 個修改檔案（types/index.ts, calculator.ts）
- 0 個破壞性變更（純擴展）
- 總行數：~1,722 lines（核心 573 + 測試 1,149）

**技術特性**:
- 基於研究文件 §4.1-4.3 完整實現
- 整合現有模組（time/solarTerms, ganZhi/conversion, ziwei/palaces）
- 類型安全（TypeScript 完整類型定義）
- 測試覆蓋完整（290+ 測試案例）
- 流年計算自動執行（使用當前日期）

---

## 下一步 (Week 2)

### ✅ Sprint 1: 核心基礎 - 完成 (Day 1-3)
- [x] Task 1.1: 時間校正模組 (8小時) ✅ 完成
  - [x] trueSolarTime / julianDay / solarTerms
- [x] Task 1.2: 干支模運算模組 (4小時) ✅ 完成
  - [x] indexToGanZhi / ganZhiToIndex
  - [x] stemModulo / branchModulo
- [x] Task 1.3: 五行關係模組 (4小時) ✅ 完成
  - [x] getWuXingRelation
  - [x] stemToWuXing / branchToWuXing

### ✅ Sprint 2: 八字計算 - 完成 (Day 4-5, 2025-11-30)
- [x] Task 2.1: 四柱排盤 (12小時) ✅ 完成 (2025-11-30)
  - [x] `fourPillars.ts` - 四柱計算 (年月日時)
  - [x] `fourPillars.test.ts` - 完整測試 (3+已知命盤)
  - **實現函數**:
    - `calculateYearPillar(solarDate, lichunTime)` - 年柱: I_year=(Y-3) mod 60
    - `calculateMonthPillar(solarLongitude, yearStemIndex)` - 月柱: 五虎遁年法
    - `calculateDayPillar(date)` - 日柱: I_day=(JDN-10) mod 60
    - `calculateHourPillar(trueSolarTime, dayStemIndex)` - 時柱: 五鼠遁日法
- [x] Task 2.2: 藏干與十神 (8小時) ✅ 完成 (2025-11-30)
  - [x] `hiddenStems.ts` - 地支藏干計算 + 權重模型
  - [x] `tenGods.ts` - 十神計算 (五行 + 陰陽邏輯)
  - [x] `hiddenStems.test.ts` - 12地支完整驗證
  - [x] `tenGods.test.ts` - 10x10矩陣完整驗證
  - **實現函數**:
    - `getHiddenStems(branch)` - 返回 HiddenStem[] (天干 + 權重 + 天數)
    - `getPrimaryHiddenStem(branch)` - 返回主氣藏干
    - `branchContainsStem(branch, stem)` - 檢查地支是否包含特定天干
    - `calculateTenGod(dayStem, targetStem)` - 返回十神類型 (比肩/劫財/食神/傷官/偏財/正財/七殺/正官/偏印/正印)
    - `getAllTenGods(dayStem)` - 返回完整十神映射表
  - **權重模型**: primary (主氣) / middle (中氣) / residual (餘氣)
  - **12地支藏干表**:
    - 子(癸) 丑(己癸辛) 寅(甲丙戊) 卯(乙) 辰(戊乙癸) 巳(丙庚戊)
    - 午(丁己) 未(己丁乙) 申(庚壬戊) 酉(辛) 戌(戊辛丁) 亥(壬甲)

### 🟢 Sprint 3: 紫微斗數模組 (Week 3)
- [x] Task 3.1: 宮位定位模組 (4小時) ✅ 完成 (2025-11-30)
  - [x] `palaces.ts` - 命宮/身宮定位計算
  - [x] `palaces.test.ts` - 144組合驗證 (12月×12時) + 閏月測試
  - **實現函數**:
    - `calculateLifePalace(lunarMonth, hourBranch, options?)` - 命宮: P_life=(M-H+1+12) mod 12
    - `calculateBodyPalace(lunarMonth, hourBranch)` - 身宮: P_body=(M+H-1) mod 12
  - **介面**: PalacePosition (position: number, branch: string)
  - **閏月支援**: leapMonthAdjustment 參數 (+1 for leap month)
- [x] Task 3.2: 五行局與紫微星 (10小時) ✅ 完成 (2025-11-30)
  - [x] `bureau.ts` - 五行局計算 (60甲子納音映射)
  - [x] `stars/ziwei.ts` - 紫微星定位 (商數餘數補償邏輯)
  - [x] `bureau.test.ts` - 60甲子完整驗證
  - [x] `stars/ziwei.test.ts` - 150組合測試 (30日×5局)
  - **實現函數**:
    - `calculateBureau(lifePalaceStem, lifePalaceBranch)` - 返回 Bureau (2=水/3=木/4=金/5=土/6=火)
    - `findZiWeiPosition(lunarDay, bureau)` - 商數餘數補償算法 + 奇偶借位邏輯
    - `calculateZiWeiPosition(lunarDay, bureau)` - 返回 ZiWeiPosition (position + branch)
  - **60甲子納音表**: 完整映射 (海中金/爐中火/大林木...大海水)
  - **定位算法**:
    - 可整除: pos = lunar_day / bureau
    - 不可整除: remainder = lunar_day % bureau, to_add = bureau - remainder
      - 奇數補償: pos = quotient - to_add
      - 偶數補償: pos = quotient + to_add
    - 映射至寅宮(index 2): final_pos = (2 + pos - 1) % 12
- [x] Task 3.3: 星曜分佈模組 (12小時) ✅ 完成 (2025-11-30)
  - [x] `stars/tianfu.ts` - 天府星定位 (對稱邏輯)
  - [x] `stars/auxiliary.ts` - 輔星定位 (文昌文曲/左輔右弼)
  - [x] `stars/tianfu.test.ts` - 對稱性驗證 + 12宮位完整測試
  - [x] `stars/auxiliary.test.ts` - 時系星/月系星完整測試
  - **實現函數**:
    - `findTianFuPosition(ziWeiPosition)` - 天府星: 與紫微星對稱於寅申軸
    - `findTimeStars(hourBranch)` - 時系星: 文昌(戌起逆行)/文曲(辰起順行)
    - `findMonthStars(lunarMonth)` - 月系星: 左輔(辰起順行)/右弼(戌起逆行)
  - **對稱算法**:
    - 天府: P_tianfu = (4 - P_ziwei) mod 12 (寅申軸對稱)
    - 文昌: (10 - hourBranch) mod 12 (戌宮起逆時針)
    - 文曲: (4 + hourBranch) mod 12 (辰宮起順時針)
    - 左輔: (4 + monthIndex) mod 12 (辰宮起順時針)
    - 右弼: (10 - monthIndex) mod 12 (戌宮起逆時針)
  - **測試覆蓋**:
    - 天府: 12宮位對稱性驗證 + 雙向映射一致性
    - 文昌文曲: 12時辰完整測試 + 順逆時針驗證
    - 左輔右弼: 12月份完整測試 + 對稱性驗證
    - 整合測試: 星曜交會點驗證

### ✅ Sprint 4: 整合與測試 - Task 4.1 完成 (2025-11-30)

#### Task 4.1: 統一計算器 (Unified Calculator)
- **狀態**: ✅ 完成 (8小時)
- **優先級**: P0

**交付檔案**:
- ✅ `types/index.ts` - 類型定義 (BirthInfo, CalculationResult, ValidationResult, BaZiResult, ZiWeiResult)
- ✅ `integration/validator.ts` - 輸入驗證 (validateBirthInfo)
- ✅ `integration/calculator.ts` - 統一計算器 (UnifiedCalculator class)
- ✅ `integration/__tests__/validator.test.ts` - 驗證器測試 (完整邊界測試)
- ✅ `integration/__tests__/calculator.test.ts` - 計算器測試 (端到端測試)

**實現函數**:
1. **類型定義** (`types/index.ts`):
   - `BirthInfo` - 輸入介面 (solarDate, longitude, gender, isLeapMonth?)
   - `BaZiResult` - 八字結果 (fourPillars, trueSolarTime, julianDay)
   - `ZiWeiResult` - 紫微結果 (lifePalace, bodyPalace, bureau, ziWeiPosition, tianFuPosition, auxiliaryStars)
   - `CalculationResult` - 統一結果 (input, bazi, ziwei, timestamp)
   - `ValidationResult` - 驗證結果 (valid, errors)

2. **輸入驗證** (`integration/validator.ts`):
   - `validateBirthInfo(input)` - 綜合驗證函數
   - 驗證項目:
     - solarDate: 必填、Date 類型、有效日期、1900-2100年範圍
     - longitude: 必填、數字、-180~180度範圍
     - gender: 必填、'male' | 'female'
     - isLeapMonth: 可選、布林值

3. **統一計算器** (`integration/calculator.ts`):
   - `UnifiedCalculator` class
   - `calculate(input)` - 主計算方法，整合 Sprint 1-3 所有模組
   - `calculateBaZi(input)` - 私有方法，計算八字四柱
   - `calculateZiWei(input, bazi)` - 私有方法，計算紫微斗數

**整合模組**:
- ✅ Core Time: trueSolarTime, julianDay, lichun
- ✅ Core GanZhi: conversion, modulo
- ✅ BaZi: fourPillars (year, month, day, hour)
- ✅ ZiWei: palaces, bureau, stars (ziwei, tianfu, auxiliary)
- ✅ lunar-typescript: Solar, Lunar 轉換

**測試覆蓋**:
- **Validator 測試** (20+ cases):
  - 有效輸入: 正確參數、男女性別、閏月、東西經度、邊界經度
  - 無效 solarDate: 缺失、非 Date、無效日期、超出範圍
  - 無效 longitude: 缺失、非數字、NaN、超出範圍
  - 無效 gender: 缺失、錯誤值
  - 無效 isLeapMonth: 非布林值
  - 多重錯誤累積
- **Calculator 測試** (15+ cases):
  - 輸入驗證: 無效輸入拋錯、缺失欄位拋錯
  - 端到端計算: 完整結果結構驗證、四柱驗證、紫微位置驗證
  - 閏月處理、性別處理、時區處理
  - 一致性測試: 相同輸入產生相同結果
  - 邊界案例: 午夜時辰、節氣邊界、極端經度

**驗收標準**:
- ✅ 端到端完整流程測試通過
- ✅ 異常輸入處理完善
- ✅ 整合 Sprint 1-3 所有模組
- ✅ 類型安全與錯誤處理
- ✅ 測試覆蓋完整 (驗證器 + 計算器)

---

### ✅ Sprint 4: 系統整合 - Task 4.2-D1 完成 (2025-11-30)

#### Task 4.2-D1: Backend API 混合架構重構 (Hybrid Architecture Redesign)
- **狀態**: ✅ 完成 (4小時)
- **優先級**: P0

**交付檔案**:
- ✅ `types/apiResponse.ts` - 新 API 回應格式定義 (混合架構)
- ✅ `controllers/purpleStarController.ts` - 混合計算器實現

**架構設計**:
1. **雙引擎混合架構**:
   - **UnifiedCalculator**: 提供核心計算 (lifePalace, bodyPalace, bureau, ziWeiPosition, tianFuPosition)
   - **Legacy PurpleStarCalculator**: 提供完整星系宮位陣列 (palaces with all stars)
   - 兩者並行運行，結果合併至新 API 格式

2. **新 API 回應格式** (`PurpleStarApiResponse`):
   ```typescript
   {
     data: {
       chart: {
         core: {  // 來自 UnifiedCalculator (數學驗證)
           lifePalace: PalacePosition,
           bodyPalace: PalacePosition,
           bureau: Bureau,
           ziWeiPosition: number,
           tianFuPosition: number
         },
         palaces: Palace[],  // 來自 Legacy (完整星系)
         mingPalaceIndex: number,  // 向後兼容
         shenPalaceIndex: number,
         mingGan?: string,
         fiveElementsBureau?: string
       }
     }
   }
   ```

3. **Controller 實現變更**:
   - **移除**: `transformToLegacyFormat()` 私有方法 (不再需要轉換)
   - **新增**: 雙引擎並行計算邏輯
   - **新增**: 增強輸入驗證 (gender 驗證、日期格式驗證)
   - **保留**: UnifiedCalculator 驗證錯誤處理

4. **輸入驗證增強**:
   - 日期格式驗證: `isNaN(solarDate.getTime())`
   - 性別驗證: `['male', 'female'].includes(gender)`
   - 驗證錯誤訊息改進: `Invalid birth date or time format`, `Invalid gender: must be "male" or "female"`

**技術優勢**:
- ✅ 核心數據採用 UnifiedCalculator (數學正確性保證)
- ✅ 完整星系採用 Legacy Calculator (豐富度保證)
- ✅ 明確資料來源分層 (core vs palaces)
- ✅ 向後兼容欄位保留 (mingPalaceIndex, shenPalaceIndex, mingGan, fiveElementsBureau)
- ✅ 更清晰的錯誤處理與驗證

**變更範圍**:
- 新增檔案: `types/apiResponse.ts` (35 lines)
- 修改檔案: `controllers/purpleStarController.ts` (86 lines, -17 lines for transformToLegacyFormat)
- API 格式: **Breaking Change** (需前端適配新格式)

**回滾計畫**:
```bash
# 回滾至 Task 4.2 初版 (transformToLegacyFormat 版本)
git checkout HEAD~1 -- peixuan-worker/src/controllers/purpleStarController.ts
# 刪除新類型檔案
rm peixuan-worker/src/types/apiResponse.ts
```

**驗收標準**:
- ✅ 建立新 API 回應類型 (`PurpleStarApiResponse`)
- ✅ UnifiedCalculator 用於 core 計算
- ✅ Legacy PurpleStarCalculator 用於 palaces 計算
- ✅ 移除 `transformToLegacyFormat()` 方法
- ✅ 增強輸入驗證與錯誤處理
- ✅ 保留向後兼容欄位

---

### ✅ Sprint A: 計算器輸出增強 - Task A1 完成 (2025-11-30)

#### Task A1: Expand UnifiedCalculator Output
- **狀態**: ✅ 完成 (3小時)
- **優先級**: P1

**交付檔案**:
- ✅ `types/index.ts` - 擴展類型定義 (新增 CalculationStep, CalculationMetadata, HiddenStems, TenGod, StarSymmetry)
- ✅ `integration/calculator.ts` - 擴展 UnifiedCalculator 實現 (填充新欄位)

**實現細節**:

1. **新增共用類型** (`types/index.ts`):
   - `CalculationStep` - 計算步驟記錄 (step, input, output, description)
   - `CalculationMetadata` - 計算元數據 (algorithms[], references[], methods[])
   - `HiddenStems` - 藏干結構 (primary, middle?, residual?)
   - `TenGod` - 十神類型 (比肩|劫財|食神|傷官|偏財|正財|七殺|正官|偏印|正印)
   - `StarSymmetry` - 星曜對稱資訊 (star, position, symmetryPair?, symmetryPosition?, symmetryType?)

2. **擴展 BaZiResult** (`types/index.ts`):
   - `hiddenStems: { year, month, day, hour }` - 四柱藏干詳細資訊
   - `tenGods: { year, month, hour }` - 十神矩陣 (相對於日干的關係)
   - `calculationSteps: CalculationStep[]` - 計算步驟追蹤
   - `metadata: CalculationMetadata` - 演算法/參考/方法資訊

3. **擴展 ZiWeiResult** (`types/index.ts`):
   - `starSymmetry: StarSymmetry[]` - 星曜對稱關係 (紫微-天府對照軸、文昌-文曲配對、左輔-右弼配對)
   - `calculationSteps: CalculationStep[]` - 計算步驟追蹤
   - `metadata: CalculationMetadata` - 演算法/參考/方法資訊

4. **擴展 Calculator 實現** (`integration/calculator.ts`):
   - **Helper Functions**:
     - `getHiddenStems(branch)` - 藏干映射 (12地支藏干表)
     - `calculateTenGod(dayStem, targetStem)` - 十神計算 (陰陽邏輯)
     - `calculateStarSymmetry(ziWei, tianFu, auxiliary)` - 星曜對稱計算

   - **BaZi 計算步驟追蹤** (7步):
     1. trueSolarTime - 真太陽時校正
     2. julianDay - 儒略日轉換
     3. yearPillar - 年柱計算 (立春界)
     4. monthPillar - 月柱計算 (太陽黃經)
     5. dayPillar - 日柱計算 (儒略日法)
     6. hourPillar - 時柱計算 (真太陽時)
     7. hiddenStems & tenGods - 藏干與十神矩陣

   - **ZiWei 計算步驟追蹤** (8步):
     1. lunarConversion - 陽曆轉農曆
     2. lifePalace - 命宮定位
     3. bodyPalace - 身宮定位
     4. bureau - 五行局計算
     5. ziWeiPosition - 紫微星定位
     6. tianFuPosition - 天府星定位
     7. timeStars - 時系星 (文昌文曲)
     8. monthStars - 月系星 (左輔右弼)

   - **Metadata 填充**:
     - BaZi algorithms: JulianDayMethod, TrueSolarTimeCorrection, LichunBoundary
     - BaZi references: 渊海子平, 三命通会, 滴天髓
     - BaZi methods: FourPillarsCalculation, HiddenStemsExtraction, TenGodsMatrix
     - ZiWei algorithms: ZiWeiPositioning, BureauCalculation, PalacePositioning
     - ZiWei references: 紫微斗数全书, 紫微斗数讲义, 骨髓赋
     - ZiWei methods: LunarCalendar, StarSymmetry, AuxiliaryStarPlacement

**技術實現**:
- **藏干映射表**: 12地支完整藏干 (子癸 丑己癸辛 寅甲丙戊 卯乙 辰戊乙癸 巳丙庚戊 午丁己 未己丁乙 申庚壬戊 酉辛 戌戊辛丁 亥壬甲)
- **十神計算**: 基於天干差值 + 陰陽性 (0-9 mod 10)
- **星曜對稱**: 紫微-天府對照 (寅申軸)、輔星配對 (文昌-文曲、左輔-右弼)

**驗收標準**:
- ✅ CalculationStep 類型定義完成
- ✅ CalculationMetadata 類型定義完成
- ✅ BaZiResult 擴展 hiddenStems + tenGods + calculationSteps + metadata
- ✅ ZiWeiResult 擴展 starSymmetry + calculationSteps + metadata
- ✅ calculator.ts 填充所有新欄位
- ✅ 計算步驟完整追蹤 (BaZi 7步 + ZiWei 8步)

**變更路徑**:
- `peixuan-worker/src/calculation/types/index.ts` (+120 lines)
- `peixuan-worker/src/calculation/integration/calculator.ts` (+180 lines)

**回滾計畫**:
```bash
git checkout HEAD~1 -- peixuan-worker/src/calculation/types/index.ts
git checkout HEAD~1 -- peixuan-worker/src/calculation/integration/calculator.ts
```

---

### ✅ Sprint A: 統一 API 整合 - Task A2 完成 (2025-11-30)

#### Task A2: Create UnifiedController
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `controllers/unifiedController.ts` - 統一控制器實現
- ✅ `routes/unifiedRoutes.ts` - 統一路由定義
- ✅ `index.ts` - 註冊統一路由至主應用

**實現細節**:

1. **UnifiedController** (`controllers/unifiedController.ts`):
   - `async calculate(requestData)` - 主計算方法
   - **輸入驗證**:
     - birthDate + birthTime → Date 格式驗證
     - gender: 'male' | 'female' 驗證
     - longitude: 預設 121.5
     - isLeapMonth: 預設 false
   - **計算流程**:
     1. 解析並驗證輸入
     2. 建立 BirthInfo 物件
     3. 呼叫 UnifiedCalculator.calculate()
     4. 返回完整 CalculationResult (無轉換)
   - **錯誤處理**:
     - 輸入驗證錯誤 → 友善錯誤訊息
     - UnifiedCalculator 驗證錯誤 → 保留原始訊息
     - 未知錯誤 → 通用錯誤訊息

2. **Unified Routes** (`routes/unifiedRoutes.ts`):
   - 路由: `POST /api/v1/calculate`
   - 使用 itty-router 註冊
   - Request body:
     ```typescript
     {
       birthDate: string,      // YYYY-MM-DD
       birthTime: string,      // HH:mm
       gender: 'male' | 'female',
       longitude?: number,     // default: 121.5
       isLeapMonth?: boolean   // default: false
     }
     ```
   - Response:
     ```typescript
     CalculationResult {
       input: BirthInfo,
       bazi: BaZiResult,      // fourPillars, hiddenStems, tenGods, steps, metadata
       ziwei: ZiWeiResult,    // palaces, bureau, stars, symmetry, steps, metadata
       timestamp: Date
     }
     ```

3. **Integration** (`index.ts`):
   - 導入 `createUnifiedRoutes` 與 `Router`
   - 在 `handleAPI()` 中註冊統一路由
   - 路由優先級: unified routes → legacy routes

**架構優勢**:
- ✅ 返回原生 CalculationResult (無資料轉換損失)
- ✅ 包含所有 Task A1 擴展欄位 (hiddenStems, tenGods, starSymmetry, calculationSteps, metadata)
- ✅ 完整計算可追溯性 (15步計算記錄)
- ✅ 與 purpleStarController 並行運行 (不影響舊 API)
- ✅ 類型安全 (端到端 TypeScript)

**API 對比**:
| 端點 | 控制器 | 計算引擎 | 輸出格式 | 用途 |
|------|--------|----------|----------|------|
| `/api/v1/purple-star/calculate` | PurpleStarController | Hybrid (Unified + Legacy) | PurpleStarApiResponse | 紫微斗數專用 (包含完整星系宮位) |
| `/api/v1/calculate` | UnifiedController | UnifiedCalculator | CalculationResult | 八字+紫微統一計算 (數學核心 + 可追溯性) |

**驗收檢查**:
- ✅ UnifiedController 建立並使用 UnifiedCalculator
- ✅ 返回完整 CalculationResult (含所有 Task A1 新欄位)
- ✅ POST /api/v1/calculate 路由註冊成功
- ✅ index.ts 整合統一路由
- ✅ 輸入驗證與錯誤處理完整

**變更路徑**:
- `peixuan-worker/src/controllers/unifiedController.ts` (新增 57 lines)
- `peixuan-worker/src/routes/unifiedRoutes.ts` (新增 45 lines)
- `peixuan-worker/src/index.ts` (修改 +7 lines)

**回滾計畫**:
```bash
# 移除新增檔案
rm peixuan-worker/src/controllers/unifiedController.ts
rm peixuan-worker/src/routes/unifiedRoutes.ts

# 回滾 index.ts
git checkout HEAD~1 -- peixuan-worker/src/index.ts
```

---

### ✅ Sprint B: 前端統一輸入表單 - Task B1 完成 (2025-11-30)

#### Task B1: Create UnifiedInputForm
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `bazi-app-vue/src/components/UnifiedInputForm.vue` - 統一輸入表單組件

**實現細節**:

1. **合併邏輯**:
   - 整合 BaziInputForm.vue 與 PurpleStarInputForm.vue
   - 保留 GeocodeService 地址轉座標功能
   - 保留時區選擇器
   - 保留快速城市選擇功能

2. **表單欄位**:
   - birthDate: 出生日期 (必填)
   - birthTime: 出生時間 (必填)
   - gender: 性別 (必填, 'male' | 'female')
   - longitude: 經度 (必填, -180~180)
   - latitude: 緯度 (可選, -90~90)
   - timezone: 時區 (必填, 預設 'Asia/Taipei')
   - isLeapMonth: 是否閏月 (可選, 布林值)

3. **地址轉座標功能**:
   - 中文地址輸入框 (防抖 800ms)
   - GeocodeService.geocodeAddress() 整合
   - 多候選地址選擇器
   - 自動填入經緯度與時區

4. **驗證規則**:
   - longitude: 必填驗證 + 範圍驗證 (-180~180)
   - latitude: 範圍驗證 (-90~90, 可選)
   - timezone: 必填驗證
   - birthDate/birthTime/gender: Element Plus 預設驗證

5. **輸出格式** (emit 'submit'):
   ```typescript
   {
     birthDate: string,      // YYYY-MM-DD
     birthTime: string,      // HH:mm
     gender: 'male' | 'female',
     longitude: number,      // 必填
     latitude?: number,      // 可選
     timezone?: string,      // 可選
     isLeapMonth?: boolean   // 可選
   }
   ```

**技術特性**:
- ✅ 響應式設計 (移動端優化)
- ✅ 時區資訊 sessionStorage 持久化
- ✅ 12個主要城市快速選擇
- ✅ 地理編碼狀態即時顯示
- ✅ 經度必填驗證與錯誤提示

**變更路徑**:
- `bazi-app-vue/src/components/UnifiedInputForm.vue` (修改 627 lines)

**回滾計畫**:
```bash
git checkout HEAD~1 -- bazi-app-vue/src/components/UnifiedInputForm.vue
```

**驗收標準**:
- ✅ 合併 BaziInputForm 與 PurpleStarInputForm 邏輯
- ✅ 保留地址轉座標功能 (GeocodeService)
- ✅ 保留時區選擇器
- ✅ 經度為必填欄位並通過驗證
- ✅ 輸出統一 birthInfo 格式: {birthDate, birthTime, gender, longitude, isLeapMonth?}

---

### 🚧 Sprint 4: 剩餘任務 (Week 3, Day 5)
- [ ] Task 4.3: 測試與文檔 (8小時)
  - [ ] 單元測試補完 (目標 > 85%)
  - [ ] 整合測試
  - [ ] API 文檔更新
  - [ ] 使用範例

### ✅ Sprint B: 前端 API 服務 - Task B2 完成 (2025-11-30)

#### Task B2: Create UnifiedApiService
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `bazi-app-vue/src/services/unifiedApiService.ts` - 統一 API 服務

**實現細節**:

1. **UnifiedApiService Class**:
   - `async calculate(birthInfo)` - 主計算方法
   - API 端點: `POST /api/v1/calculate`
   - 輸入: UnifiedCalculateRequest
   - 輸出: CalculationResult

2. **類型定義**:
   - `UnifiedCalculateRequest` - 請求格式 (birthDate, birthTime, gender, longitude?, isLeapMonth?)
   - `CalculationResult` - 回應格式 (input, bazi, ziwei, timestamp)
   - `BaZiResult` - 八字結果 (fourPillars, hiddenStems, tenGods, calculationSteps, metadata)
   - `ZiWeiResult` - 紫微結果 (lifePalace, bodyPalace, bureau, stars, starSymmetry, calculationSteps, metadata)
   - `ApiResponse<T>` - API 回應包裝器

3. **錯誤處理**:
   - 400 錯誤 → `輸入驗證錯誤: {詳細訊息}`
   - 500 錯誤 → `伺服器計算錯誤: {詳細訊息}`
   - 網路錯誤 → `無法連接到伺服器，請檢查網路連接`
   - 未知錯誤 → `計算過程發生未知錯誤`

4. **快取機制**:
   - 快取 TTL: 5 分鐘
   - 快取 key: `birthDate_birthTime_gender_longitude_isLeapMonth`
   - 快取管理: 最多保留 50 筆記錄 (LRU)
   - 手動清除: `clearCache()`

5. **參考 apiService.ts 模式**:
   - 使用 axios
   - BASE_URL = '/api/v1'
   - console.log 詳細記錄
   - 單例模式 (export default new UnifiedApiService())

**技術特性**:
- ✅ 類型安全 (完整 TypeScript 介面定義)
- ✅ 友善錯誤訊息 (狀態碼分類處理)
- ✅ 自動快取機制 (減少重複計算)
- ✅ 快取過期檢查 (5分鐘 TTL)
- ✅ 快取大小限制 (最多 50 筆)

**變更路徑**:
- `bazi-app-vue/src/services/unifiedApiService.ts` (新增 269 lines)

**回滾計畫**:
```bash
rm bazi-app-vue/src/services/unifiedApiService.ts
```

**驗收標準**:
- ✅ calculate(birthInfo) 方法呼叫 POST /api/v1/calculate
- ✅ 錯誤處理包含友善訊息
- ✅ 請求/回應類型定義匹配後端 CalculationResult
- ✅ 簡單快取機制實現 (5分鐘 TTL, 50筆上限)
- ✅ 參考 apiService.ts 模式 (axios, BASE_URL, console.log, 單例)

---

### ✅ Sprint 2: 八字計算 - Task 2.3-2.4 完成 (2025-11-30)

#### Task 2.3: 五行時令模組 (WuXing Seasonality Module)
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `wuXing/seasonality.ts` - 五行時令旺衰計算
- ✅ `wuXing/__tests__/seasonality.test.ts` - 完整測試覆蓋

**實現函數**:
1. **季節映射** (`getSeasonFromBranch`):
   - Spring (春): 寅卯
   - Summer (夏): 巳午
   - Autumn (秋): 申酉
   - Winter (冬): 亥子
   - Transitional (四季): 辰戌丑未

2. **時令係數表** (`getSeasonalityCoefficient`):
   - Spring: Wood 1.5 / Fire 1.3 / Water 1.0 / Earth 0.7 / Metal 0.5
   - Summer: Fire 1.5 / Earth 1.3 / Wood 1.0 / Metal 0.7 / Water 0.5
   - Autumn: Metal 1.5 / Water 1.3 / Earth 1.0 / Wood 0.7 / Fire 0.5
   - Winter: Water 1.5 / Wood 1.3 / Metal 1.0 / Fire 0.7 / Earth 0.5
   - Transitional: Earth 1.5 / Metal 1.3 / Fire 1.0 / Water 0.7 / Wood 0.5

3. **時令調整** (`applySeasonalityAdjustment`):
   - 輸入: Record<WuXing, number> 五行分數
   - 處理: 依月支取得季節,套用對應係數
   - 輸出: 調整後五行分數

**測試覆蓋**:
- 12地支季節映射測試 (完整驗證)
- 5季 × 5元素係數矩陣驗證 (25組測試)
- 時令調整計算測試 (基準分數 + 自訂分數)
- 異常輸入處理 (無效月支)

**技術細節**:
- 基於: 八字命理後端模組研究.md §2.3.1
- 實現五行旺衰時令規則
- 季節係數矩陣 (5×5)
- 依月支自動計算季節影響

**變更路徑**:
- `peixuan-worker/src/calculation/wuXing/seasonality.ts` (新增 61 lines)
- `peixuan-worker/src/calculation/wuXing/__tests__/seasonality.test.ts` (新增 153 lines)

#### Task 2.4: 五行分布統計模組 (WuXing Distribution Module)
- **狀態**: ✅ 完成 (3小時)
- **優先級**: P1

**交付檔案**:
- ✅ `wuXing/distribution.ts` - 五行分布統計計算
- ✅ `wuXing/__tests__/distribution.test.ts` - 完整測試覆蓋

**實現函數**:
1. **天干計數** (`getTianganScores`):
   - 權重: 1.0 每個天干
   - 輸入: 四柱天干陣列
   - 輸出: Record<WuXing, number> 五行計數

2. **藏干加權計數** (`getHiddenStemScores`):
   - 權重模型:
     - Primary (主氣): 單藏干 1.0 / 多藏干 0.6
     - Middle (中氣): 0.3
     - Residual (餘氣): 0.1
   - 整合 `getHiddenStems` 從 bazi/hiddenStems.ts
   - 使用 `stemToWuXing` 從 core/wuXing/relations.ts

3. **總分計算** (`getTotalScores`):
   - 公式: Total_Score[Element] = (Tiangan_Count + Hidden_Stem_Weighted_Sum) * Seasonality_Coefficient
   - 整合 `applySeasonalityAdjustment` 從 seasonality.ts
   - 依月支時令調整

4. **五行分布計算** (`calculateWuXingDistribution`):
   - 輸入: FourPillars { year, month, day, hour }
   - 輸出: WuXingDistribution
     - raw.tiangan: 天干原始計數
     - raw.hiddenStems: 藏干加權分數
     - adjusted: 時令調整後分數
     - dominant: 最強五行
     - deficient: 最弱五行
     - balance: 平衡度 (0-1, 公式: 1 - stddev/mean)

**測試覆蓋**:
- 天干計數測試 (單一元素 + 累積測試)
- 藏干加權測試 (研究文件案例: 子寅辰酉)
- 時令調整測試 (春秋對比)
- 完整分布計算測試 (已知命盤驗證)
- 極端案例測試:
  - 單一五行主導 (全木 / 全金)
  - 缺失五行識別
  - 平衡度計算驗證

**技術細節**:
- 基於: 八字命理後端模組研究.md §2.1-2.3
- 藏干權重模型 (分氣法)
- 月令強弱係數矩陣整合
- 標準差平衡度計算

**變更路徑**:
- `peixuan-worker/src/calculation/wuXing/distribution.ts` (新增 210 lines)
- `peixuan-worker/src/calculation/wuXing/__tests__/distribution.test.ts` (新增 240 lines)

---

### ✅ Sprint R2: 核心整合增強 - Task R2.3 完成 (2025-11-30)

#### Task R2.3: Integrate WuXingDistribution into UnifiedCalculator
- **狀態**: ✅ 完成 (1小時)
- **優先級**: P1

**交付檔案**:
- ✅ `types/index.ts` - 新增 wuxingDistribution 到 BaZiResult 介面
- ✅ `integration/calculator.ts` - 整合 WuXing 分布計算

**實現細節**:

1. **類型擴展** (`types/index.ts`):
   - 導入 `WuXingDistribution` 從 `wuXing/distribution`
   - BaZiResult 介面新增 `wuxingDistribution: WuXingDistribution` 欄位

2. **Calculator 整合** (`integration/calculator.ts`):
   - 導入 `calculateWuXingDistribution` 函數
   - calculateBaZi() 方法中:
     - 調用 `calculateWuXingDistribution(fourPillars)` 計算五行分布
     - 新增 calculationStep 'wuxingDistribution' 記錄計算過程
     - 更新 metadata.methods 包含 'SeasonalityAdjustment'
     - 將結果賦值至 BaZiResult.wuxingDistribution

3. **計算流程**:
   - 在十神計算之後執行
   - 使用四柱干支數據 (stem + branch)
   - 包含天干計數 + 藏干加權 + 時令調整
   - 自動記錄計算步驟 (description: 'Calculate WuXing distribution with seasonality adjustment')

**技術整合**:
- ✅ 五行分布納入核心計算結果
- ✅ 計算步驟追蹤完整性
- ✅ Metadata 方法列表更新
- ✅ 類型安全保證

**變更路徑**:
- `peixuan-worker/src/calculation/types/index.ts` (+2 lines)
- `peixuan-worker/src/calculation/integration/calculator.ts` (+14 lines)

**驗收標準**:
- ✅ BaZiResult 介面包含 wuxingDistribution 欄位
- ✅ UnifiedCalculator.calculateBaZi() 填充 wuxingDistribution
- ✅ calculationSteps 包含 'wuxingDistribution' 步驟
- ✅ metadata.methods 包含 'SeasonalityAdjustment'

---

### ✅ Sprint 3: 大運計算 - Task 3.1 完成 (2025-11-30)

#### Task 3.1: QiYun (起運) 計算模組
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `fortune/qiyun.ts` - 起運計算核心邏輯
- ✅ `fortune/__tests__/qiyun.test.ts` - 完整測試覆蓋 (70+ cases)
- ✅ `fortune/index.ts` - 模組匯出

**實現函數**:
1. **起運方向判定** (`determineFortuneDirection`):
   - 邏輯表 (§3.2.1):
     - 男陽順 (Male + Yang Stem): 'forward'
     - 男陰逆 (Male + Yin Stem): 'backward'
     - 女陽逆 (Female + Yang Stem): 'backward'
     - 女陰順 (Female + Yin Stem): 'forward'
   - 陽干: 甲丙戊庚壬
   - 陰干: 乙丁己辛癸

2. **起運日期計算** (`calculateQiYunDate`):
   - 基於方向找到最近節氣 (Jie)
   - 計算時間差 (分鐘)
   - 代謝轉換公式 (§3.2.2):
     - Metabolic_Days = Diff_Minutes / 1440
     - Total_Real_Days = Metabolic_Days × 120
     - QiYun_Date = Birth_Date + Total_Real_Days
   - 整合 getSolarTermTime 從 core/time/solarTerms.ts

3. **代謝日數轉換** (`convertMetabolicDays`):
   - 輸入: 分鐘差值
   - 輸出: {years, months, days}
   - 公式: 3 metabolic days = 1 year (120 real days each)

**測試覆蓋**:
- **方向邏輯測試** (20 cases):
  - 男陽順 (5 Yang stems × male)
  - 男陰逆 (5 Yin stems × male)
  - 女陽逆 (5 Yang stems × female)
  - 女陰順 (5 Yin stems × female)
- **時間轉換測試** (5 cases):
  - 3 days = ~1 year
  - 6 hours = 1 month
  - 1 hour = 5 days
  - 30 days = ~10 years
- **邊界案例測試** (10 cases):
  - 出生靠近節氣 (1天內)
  - 出生遠離節氣
  - 年度邊界 (元旦前後)
  - 閏年出生 (2/29)
  - 不同時區 (真太陽時)
- **整合測試** (35 cases):
  - 10 天干完整測試
  - 一致性測試 (相同輸入)
  - 端到端完整計算

**技術細節**:
- 基於: 八字命理後端模組研究.md §3.2
- 節氣查詢: 使用 SOLAR_TERMS (24節氣) 過濾 Jie (12節)
- 方向邏輯: XOR (男陽/女陰順行, 男陰/女陽逆行)
- 時間精度: 分鐘級計算
- 日期處理: Date 物件原生加法

**變更路徑**:
- `peixuan-worker/src/calculation/fortune/qiyun.ts` (新增 190 lines)
- `peixuan-worker/src/calculation/fortune/__tests__/qiyun.test.ts` (新增 245 lines)
- `peixuan-worker/src/calculation/fortune/index.ts` (新增 6 lines)

**回滾計畫**:
```bash
rm -rf peixuan-worker/src/calculation/fortune
```

**驗收標準**:
- ✅ determineFortuneDirection 實現四種組合邏輯
- ✅ calculateQiYunDate 實現完整計算公式
- ✅ convertMetabolicDays 實現時間轉換
- ✅ 整合 getSolarTermTime 獲取節氣
- ✅ 測試覆蓋 70+ cases (方向 + 轉換 + 邊界 + 整合)

---

### ✅ Sprint 3: 大運計算 - Task 3.2 完成 (2025-11-30)

#### Task 3.2: DaYun (大運) 生成模組
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `fortune/dayun.ts` - 大運生成與當前週期偵測
- ✅ `fortune/__tests__/dayun.test.ts` - 完整測試覆蓋 (50+ cases)

**實現函數**:
1. **大運列表生成** (`generateDaYunList`):
   - 參數:
     - monthPillar: GanZhi (月柱干支作為基準)
     - qiyunDate: Date (起運日期)
     - direction: 'forward' | 'backward' (順行/逆行)
     - count: number (生成週期數, 預設 10)
   - 順行邏輯 (§3.3):
     - 月柱甲子 → 第一運乙丑 → 第二運丙寅 (60甲子遞增)
     - 使用 indexToGanZhi 從 ganZhi/conversion.ts
   - 逆行邏輯:
     - 月柱甲子 → 第一運癸亥 → 第二運壬戌 (60甲子遞減)
     - 模運算處理邊界 (index + 60) % 60
   - 每運 10 年間隔
   - 返回 DaYun[] (stem, branch, startDate, endDate, age)

2. **當前大運偵測** (`getCurrentDaYun`):
   - 參數:
     - dayunList: DaYun[] (大運列表)
     - queryDate: Date (查詢日期)
   - 邏輯 (§3.4):
     - 遍歷列表尋找: startDate ≤ queryDate < endDate
     - 包含起始邊界 (inclusive start)
     - 排除結束邊界 (exclusive end)
   - 返回: DaYun | null (若無符合則返回 null)

**資料結構**:
- `DaYun` interface:
  - stem: string (天干)
  - branch: string (地支)
  - startDate: Date (週期開始)
  - endDate: Date (週期結束, exclusive)
  - age: number (起運年齡: 0, 10, 20, 30...)

**測試覆蓋**:
- **順行生成測試** (10 cases):
  - 甲子 → 乙丑 → 丙寅 → 丁卯
  - 60甲子循環邊界 (癸亥 → 甲子)
  - 年齡遞增驗證 (0, 10, 20...)
- **逆行生成測試** (10 cases):
  - 甲子 → 癸亥 → 壬戌 → 辛酉
  - 60甲子循環邊界 (甲子 → 癸亥)
  - 年齡遞增驗證
- **10年間隔驗證** (8 cases):
  - startDate 精確性 (qiyunDate + index*10年)
  - endDate 精確性 (startDate + 10年)
  - 時間元件保留 (小時/分/秒/毫秒)
  - 閏年邊界處理 (2/29 起運)
- **當前週期偵測測試** (10 cases):
  - 第一週期內查詢
  - 中間週期查詢
  - 週期邊界查詢 (inclusive start)
  - 結束日期排除測試 (exclusive end)
  - 查詢早於首週期 → null
  - 查詢晚於末週期 → null
  - 毫秒級精確比對
- **邊界案例測試** (12 cases):
  - 空列表處理 (count=0)
  - 單一週期處理 (count=1)
  - 預設參數測試 (count=10)
  - 60週期完整循環 (驗證循環一致性)
  - 不同起點測試 (庚午起始)
- **一致性測試** (5 cases):
  - 順行 60 週期回到起點
  - 逆行 60 週期回到起點
  - 順逆對比差異驗證

**技術細節**:
- 基於: 八字命理後端模組研究.md §3.3-3.4
- 60甲子轉換: ganZhiToIndex / indexToGanZhi
- 日期計算: Date.setFullYear() 原生方法
- 邊界處理: 模運算 ((index ± 1) + 60) % 60
- 時間保留: 保持原始 qiyunDate 的時分秒毫秒

**變更路徑**:
- `peixuan-worker/src/calculation/fortune/dayun.ts` (新增 127 lines)
- `peixuan-worker/src/calculation/fortune/__tests__/dayun.test.ts` (新增 323 lines)

**回滾計畫**:
```bash
rm peixuan-worker/src/calculation/fortune/dayun.ts
rm peixuan-worker/src/calculation/fortune/__tests__/dayun.test.ts
```

**驗收標準**:
- ✅ DaYun 介面定義 (stem, branch, startDate, endDate, age)
- ✅ generateDaYunList 實現順逆行邏輯
- ✅ 60甲子正確遞增/遞減 (使用 indexToGanZhi)
- ✅ 每運 10 年精確間隔
- ✅ getCurrentDaYun 實現週期偵測 (startDate ≤ query < endDate)
- ✅ 測試覆蓋 50+ cases (順行/逆行/間隔/偵測/邊界)

---

### ✅ Sprint R3: FortuneCycles 整合 - Task R3.3 完成 (2025-11-30)

#### Task R3.3: Integrate FortuneCycles into UnifiedCalculator
- **狀態**: ✅ 完成 (1小時)
- **優先級**: P1

**交付檔案**:
- ✅ `types/index.ts` - 新增 fortuneCycles 到 BaZiResult 介面
- ✅ `integration/calculator.ts` - 整合起運與大運計算

**實現細節**:

1. **類型擴展** (`types/index.ts`):
   - 導入 `DaYun` 從 `fortune/dayun`
   - BaZiResult 介面新增 `fortuneCycles` 欄位:
     ```typescript
     fortuneCycles: {
       qiyunDate: Date,
       direction: 'forward' | 'backward',
       dayunList: DaYun[],
       currentDayun: DaYun | null
     }
     ```

2. **Calculator 整合** (`integration/calculator.ts`):
   - 導入 `determineFortuneDirection`, `calculateQiYunDate` 從 `fortune/qiyun`
   - 導入 `generateDaYunList`, `getCurrentDaYun` 從 `fortune/dayun`
   - calculateBaZi() 方法中:
     - 調用 `determineFortuneDirection(yearStem, gender)` 判定順逆
     - 調用 `calculateQiYunDate(solarDate, yearStem, gender, trueSolarTime)` 計算起運日期
     - 新增 calculationStep 'qiyunCalculation' 記錄起運計算
     - 調用 `generateDaYunList(monthPillar, qiyunDate, direction, 10)` 生成 10 個大運
     - 調用 `getCurrentDaYun(dayunList, new Date())` 偵測當前大運
     - 新增 calculationStep 'dayunGeneration' 記錄大運生成
     - 更新 metadata.methods 包含 'MetabolicConversion' 和 'FortuneDirection'
     - 將結果賦值至 BaZiResult.fortuneCycles

3. **計算流程**:
   - 在五行分布計算之後執行
   - 使用年干 (yearStem) 和性別 (gender) 判定方向
   - 使用月柱干支作為大運基準
   - 生成 10 個 10 年大運週期
   - 自動偵測當前所處大運

**技術整合**:
- ✅ 起運與大運納入核心計算結果
- ✅ 計算步驟追蹤完整性 (新增 2 步)
- ✅ Metadata 方法列表更新 (新增 2 方法)
- ✅ 類型安全保證 (DaYun 介面整合)

**變更路徑**:
- `peixuan-worker/src/calculation/types/index.ts` (+13 lines)
- `peixuan-worker/src/calculation/integration/calculator.ts` (+35 lines)

**驗收標準**:
- ✅ BaZiResult 介面包含 fortuneCycles 欄位
- ✅ UnifiedCalculator.calculateBaZi() 填充 fortuneCycles
- ✅ calculationSteps 包含 'qiyunCalculation' 和 'dayunGeneration' 步驟
- ✅ metadata.methods 包含 'MetabolicConversion' 和 'FortuneDirection'
- ✅ 保持最小變更原則 (僅整合,不重構)

---

### ✅ Sprint 4: 流年計算 - Task 4.1 完成 (2025-11-30)

#### Task 4.1: 流年年柱計算模組 (Annual Pillar with LiChun Boundary)
- **狀態**: ✅ 完成 (1小時)
- **優先級**: P1

**交付檔案**:
- ✅ `annual/liuchun.ts` - 流年年柱計算 (立春界)
- ✅ `annual/__tests__/liuchun.test.ts` - 完整測試覆蓋 (40+ cases)

**實現函數**:
1. **年柱計算** (`getAnnualPillar`):
   - 參數: queryDate (查詢日期)
   - 立春界判定 (§4.1):
     - queryDate < 立春 → 使用前一年干支
     - queryDate >= 立春 → 使用當年干支
   - 年柱公式: year_index = (year - 4) mod 60
   - 基準年: 4 CE = 甲子 (index 0)
   - 返回: GanZhi (stem, branch)

2. **立春判定** (`hasPassedLiChun`):
   - 參數: queryDate (查詢日期)
   - 判定: queryDate >= getLichunTime(year)
   - 返回: boolean

**測試覆蓋**:
- **立春邊界測試** (10 cases):
  - 立春前一天 → 前一年干支
  - 立春後一天 → 當年干支
  - 立春當下 → 當年干支 (inclusive)
  - 立春前一秒 → 前一年干支
- **年度交界測試** (8 cases):
  - 12/31 (立春前) → 當年干支
  - 1/1 (立春前) → 前一年干支
  - 農曆新年 vs 立春差異 (2/10 vs 2/4)
- **邊界案例測試** (12 cases):
  - 閏年處理 (2024-02-29)
  - 年份計算正確性 (2000 → 庚辰, 1984 → 甲子, 1924 → 甲子)
  - 60年週期一致性
  - 時區處理 (UTC vs +08:00)
- **歷史日期測試** (10 cases):
  - 1950 → 庚寅
  - 1975 → 乙卯
  - 早期20世紀驗證

**技術細節**:
- 基於: 八字命理後端模組研究.md §4.1
- 整合 `getLichunTime` 從 core/time/solarTerms.ts
- 整合 `indexToGanZhi` 從 ganZhi/conversion.ts
- 年柱公式: (year - 4) % 60 (年4 CE = 甲子起點)
- 精確到毫秒級立春時刻判定

**變更路徑**:
- `peixuan-worker/src/calculation/annual/liuchun.ts` (新增 73 lines)
- `peixuan-worker/src/calculation/annual/__tests__/liuchun.test.ts` (新增 189 lines)

**回滾計畫**:
```bash
rm -rf peixuan-worker/src/calculation/annual
```

**驗收標準**:
- ✅ getAnnualPillar 實現立春界判定邏輯
- ✅ hasPassedLiChun 實現立春時刻比對
- ✅ 年柱公式正確 (year - 4) mod 60
- ✅ 整合現有 getLichunTime 和 indexToGanZhi
- ✅ 測試覆蓋 40+ cases (邊界/交界/閏年/時區/歷史)

---

### ✅ Sprint 4: 流年計算 - Task 4.2 完成 (2025-11-30)

#### Task 4.2: 流年命宮定位模組 (Annual Palace Positioning)
- **狀態**: ✅ 完成 (1小時)
- **優先級**: P1

**交付檔案**:
- ✅ `annual/palace.ts` - 流年命宮定位與宮位旋轉
- ✅ `annual/__tests__/palace.test.ts` - 完整測試覆蓋 (100+ cases)

**實現函數**:
1. **流年命宮定位** (`locateAnnualLifePalace`):
   - 參數:
     - annualBranch: string (流年地支, 如 "寅" for 壬寅年)
     - ziweiPalaces: Palace[] (紫微盤 12 宮位陣列)
   - 邏輯 (§4.2):
     - 在紫微盤的 12 宮位陣列中查找地支為 annualBranch 的宮位
     - 返回該宮位的索引 (0-11)
   - 驗證:
     - 檢查 annualBranch 為有效地支
     - 檢查 ziweiPalaces 長度為 12
   - 返回: number (宮位索引) 或 -1 (未找到)

2. **宮位意義旋轉** (`rotateAnnualPalaces`):
   - 參數:
     - basePalaces: Palace[] (基礎紫微宮位陣列)
     - annualLifePalaceIndex: number (流年命宮索引, 0-11)
   - 邏輯:
     - 一旦流年命宮確定,其餘 11 宮意義隨之旋轉
     - 例: 流年命宮在 index 3 → index 3 為"命宮", index 4 為"兄弟宮"
   - 旋轉規則:
     - meaningIndex = (currentIndex - annualLifePalaceIndex + 12) % 12
     - 宮位意義順序: 命宮 → 兄弟宮 → 夫妻宮 → 子女宮 → 財帛宮 → 疾厄宮 → 遷移宮 → 奴僕宮 → 官祿宮 → 田宅宮 → 福德宮 → 父母宮
   - 返回: Palace[] (包含 position, branch, meaning)

3. **輔助函數** (`createPalaceArray`):
   - 參數: startBranch: string (起始地支)
   - 功能: 建立標準 12 宮位陣列 (從指定地支開始順時針排列)
   - 用途: 測試與初始化
   - 返回: Palace[]

**資料結構**:
- `Palace` interface:
  - position: number (宮位索引 0-11)
  - branch: string (地支名稱)
  - meaning?: string (宮位意義, 如 "命宮", "兄弟宮")

**測試覆蓋**:
- **12地支定位測試** (14 cases):
  - 子丑寅卯辰巳午未申酉戌亥 完整定位驗證
  - 偏移宮位陣列測試 (從寅起始, 從午起始)
- **宮位旋轉測試** (30 cases):
  - index 0 旋轉 (無旋轉基準測試)
  - index 3 旋轉 (卯位為命宮)
  - index 6 旋轉 (午位為命宮)
  - index 11 旋轉 (亥位為命宮)
  - 完整 12 位置循環測試
  - 地支保留驗證 (旋轉不改變地支)
- **邊界案例測試** (20 cases):
  - 空字串地支 → -1
  - 無效地支 (天干"甲") → -1
  - null/undefined palaces → -1
  - 空 palaces 陣列 → -1
  - palaces 長度錯誤 → -1
  - 負數索引 → 空陣列
  - 索引 > 11 → 空陣列
  - 地支不存在於 palaces → -1
- **整合測試** (6 cases):
  - 壬寅年 (2022) 實際案例
  - 癸卯年 (2023) 實際案例
  - 完整工作流: locate → rotate → verify
  - 所有宮位包含完整欄位驗證

**技術細節**:
- 基於: 八字命理後端模組研究.md §4.2
- 地支陣列: 子丑寅卯辰巳午未申酉戌亥 (固定順序)
- 宮位意義: 12 個標準宮位名稱 (命宮起順時針)
- 模運算: (index + offset) % 12 處理循環邊界
- 保持宮位原始 position 與 branch 不變

**變更路徑**:
- `peixuan-worker/src/calculation/annual/palace.ts` (新增 170 lines)
- `peixuan-worker/src/calculation/annual/__tests__/palace.test.ts` (新增 335 lines)

**回滾計畫**:
```bash
rm peixuan-worker/src/calculation/annual/palace.ts
rm peixuan-worker/src/calculation/annual/__tests__/palace.test.ts
```

**驗收標準**:
- ✅ locateAnnualLifePalace 實現流年命宮定位
- ✅ rotateAnnualPalaces 實現宮位意義旋轉
- ✅ createPalaceArray 輔助函數實現
- ✅ Palace 介面定義 (position, branch, meaning)
- ✅ 測試覆蓋 100+ cases (12地支/旋轉/邊界/整合)

---

### ✅ Sprint 4: 流年計算 - Task 4.3 完成 (2025-11-30)

#### Task 4.3: 流年交互分析模組 (Annual Interaction Analysis)
- **狀態**: ✅ 完成 (2小時)
- **優先級**: P1

**交付檔案**:
- ✅ `annual/interaction.ts` - 干支交互檢測 (合沖害)
- ✅ `annual/__tests__/interaction.test.ts` - 完整測試覆蓋 (150+ cases)

**實現函數**:
1. **天干五合檢測** (`detectStemCombinations`):
   - 參數:
     - annualStem: HeavenlyStem (流年天干)
     - fourPillars: FourPillars (本命四柱)
   - 檢測規則 (§4.3.1):
     - 甲己合土 (Jia-Ji → Earth)
     - 乙庚合金 (Yi-Geng → Metal)
     - 丙辛合水 (Bing-Xin → Water)
     - 丁壬合木 (Ding-Ren → Wood)
     - 戊癸合火 (Wu-Gui → Fire)
   - 返回: StemCombination[] {pillar, element}

2. **地支六沖檢測** (`detectBranchClashes`):
   - 參數:
     - annualBranch: EarthlyBranch (流年地支)
     - fourPillars: FourPillars (本命四柱)
   - 檢測規則 (§4.3.1):
     - 子午沖, 丑未沖, 寅申沖, 卯酉沖, 辰戌沖, 巳亥沖
   - 嚴重度分級 (§4.3.1):
     - Day pillar (日支): HIGH (affects spouse/health)
     - Month pillar (月支): MEDIUM (affects parents/career)
     - Year/Hour pillar (年/時支): LOW (general tai sui clash)
   - 返回: BranchClash[] {pillar, severity}

3. **三合三會檢測** (`detectHarmoniousCombinations`):
   - 參數:
     - annualBranch: EarthlyBranch (流年地支)
     - fourPillars: FourPillars (本命四柱)
     - dayunBranch?: EarthlyBranch (可選: 大運地支)
   - 檢測規則 (§4.3.1):
     - **三合 (Triple Harmony)**:
       - 申子辰合水局 (Shen-Zi-Chen → Water)
       - 亥卯未合木局 (Hai-Mao-Wei → Wood)
       - 寅午戌合火局 (Yin-Wu-Xu → Fire)
       - 巳酉丑合金局 (Si-You-Chou → Metal)
     - **三會 (Triple Assembly)**:
       - 寅卯辰會木局 (Yin-Mao-Chen → Wood, Spring)
       - 巳午未會火局 (Si-Wu-Wei → Fire, Summer)
       - 申酉戌會金局 (Shen-You-Xu → Metal, Autumn)
       - 亥子丑會水局 (Hai-Zi-Chou → Water, Winter)
   - 算法: 集合運算 (Set Theory)
     - 收集所有地支: annualBranch + fourPillars.branches + dayunBranch
     - 檢查是否包含完整三合/三會子集
   - 返回: HarmoniousCombination[] {type, branches, element}

**資料結構**:
- `StemCombination`:
  - pillar: 'year' | 'month' | 'day' | 'hour'
  - element: WuXing (合化五行)
- `BranchClash`:
  - pillar: 'year' | 'month' | 'day' | 'hour'
  - severity: 'high' | 'medium' | 'low'
- `HarmoniousCombination`:
  - type: 'sanhe' | 'sanhui' (三合/三會)
  - branches: EarthlyBranch[] (組成地支)
  - element: WuXing (合化五行)

**測試覆蓋**:
- **天干五合測試** (40 cases):
  - 甲己合土 (5 組合測試)
  - 乙庚合金 (5 組合測試)
  - 丙辛合水 (5 組合測試)
  - 丁壬合木 (5 組合測試)
  - 戊癸合火 (5 組合測試)
  - 多重組合測試 (同一天干合多個地支)
  - 無組合情況測試
- **地支六沖測試** (50 cases):
  - 六組沖對測試 (子午/丑未/寅申/卯酉/辰戌/巳亥)
  - 嚴重度分級驗證 (high/medium/low)
  - 多重沖擊測試
  - 無沖擊情況測試
- **三合三會測試** (40 cases):
  - 四組三合測試 (申子辰/亥卯未/寅午戌/巳酉丑)
  - 四組三會測試 (寅卯辰/巳午未/申酉戌/亥子丑)
  - 包含大運地支的組合
  - 同時出現三合+三會 (雙重組合)
- **邊界案例測試** (20 cases):
  - 空四柱處理
  - 重複地支處理
  - 無 dayunBranch 參數測試
  - 所有函數返回空陣列情況
- **整合測試** (10 cases):
  - 同時檢測合沖害 (多函數協作)
  - 實際命盤案例驗證

**技術細節**:
- 基於: 八字命理後端模組研究.md §4.3
- 天干組合映射表 (Record<string, {partner, element}>)
- 地支沖對映射表 (Record<EarthlyBranch, EarthlyBranch>)
- 三合陣列 (Array<{branches, element}>)
- 三會陣列 (Array<{branches, element}>)
- 集合運算: Set<EarthlyBranch> 檢查完整子集

**變更路徑**:
- `peixuan-worker/src/calculation/annual/interaction.ts` (新增 330 lines)
- `peixuan-worker/src/calculation/annual/__tests__/interaction.test.ts` (新增 625 lines)

**回滾計畫**:
```bash
rm peixuan-worker/src/calculation/annual/interaction.ts
rm peixuan-worker/src/calculation/annual/__tests__/interaction.test.ts
```

**驗收標準**:
- ✅ detectStemCombinations 實現天干五合檢測 (甲己/乙庚/丙辛/丁壬/戊癸)
- ✅ detectBranchClashes 實現地支六沖檢測 + 嚴重度分級
- ✅ detectHarmoniousCombinations 實現三合三會檢測 (含可選大運地支)
- ✅ 使用 FourPillars 類型從 types/index.ts
- ✅ 測試覆蓋 150+ cases (合沖害/三合三會/邊界/整合)

---

### 📋 其他任務
- [ ] 移除前端 ziweiCalc.ts
- [ ] 更新 README.md (backend-node → peixuan-worker)
- [ ] 建立完整 ARCHITECTURE.md
- [ ] 實現缺失功能（四化飛星、流年太歲）
- [ ] 提取為共享 npm 包
- [ ] 提升測試覆蓋率

---

**備註**: 詳細記錄已存檔至 `.specify/memory/audit_trail.log`
